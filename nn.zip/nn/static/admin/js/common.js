// iframe 内使用的公共js 
$(function(){
	$.ajaxSetup({
		dataType: 'json',
		beforeSend: function(){
			layer.load(1, {
			    shade: [0.1,'#fff']
			});
		},
		complete: function(){
			layer.closeAll('loading');
		}
	});
	// 触发父框架的click事件，用于关闭右键菜单
	$(document).on('click', 'html',function(){
		if($(".dropdown-menu", top.document).length != 0)
			$('html', top.document).click();
	});

	// 设置title
	$("title", window.top.document).html($("title").html());

	// 设置iframe高
	// todo.. 修正奇怪的155，如果用$(document).height(),只有第一次载入时值是正确的，以后的值都会变成上个点击页面的高度
	var h = $(document.body).height()+155;
	$(".iframe[name="+top.iframe_active+"]", window.top.document).height(h);

	// var hf = location.href;
	// 	hf = hf.replace('http://new.com/admin/', '');
	// 	if(hf.indexOf('/') == -1) hf += '/index';

	// c(hf+' 开始设置iframe高度为：'+h)
	
	// $("#iframe", window.top.document).load(function(){
	// 	// var h = document.body.scrollHeight+200;
	// 	// var h = $(document).height();
	// 	// // var h = $(document.body).height();
	// 	// // var h = $(document.body).outerHeight();
	// 	// $(this).height(h);
	// 	// var hf = location.href;
	// 	// hf = hf.replace('http://new.com/admin/', '');
	// 	// if(hf.indexOf('/') == -1) hf += '/index';
	// 	// c(hf+' 开始设置iframe高度为：'+h)
		
	// });

	// 针对bootstrap这种html结构
	// 点击checkbox/radio切换
	$("body").delegate('input[type=checkbox],input[type=radio]', 'click', function(e) {
		var _span = $(this).parent('span'),
			type = $(this).attr('type');

		if(type == 'checkbox'){
			if(_span.hasClass('checked')){
				_span.removeClass('checked').children().prop('checked', false);
			}else{
				_span.addClass('checked').children().prop('checked', true);
			}
		}else if(type == 'radio'){
			if(_span.hasClass('checked')) return;
			var radio_group = $(this).closest('label.radio').parent().children();
			radio_group.find('span').removeClass('checked').children().prop('checked', false);
			_span.addClass('checked').children().prop('checked', true);
		}
		// return false;
		// e.stopPropagation();
		
	});

	// 公共搜索
	$("#search").click(function() {
		var baseurl = window.baseurl || location.href,
			inputs = $(this).closest('.pull-left').find('input,select'),
			page = $('#pagelist .active').text() || 1,
			data = '?',
			name,
			type,
			value;
		inputs.each(function() {
			type = $(this).attr('type');
			name = $(this).attr('name');
			value = $(this).val();
			if(type == 'radio'){
				if(!$(this).attr('checked')) return true;
			}

			data += name+'='+value+'&';
		});
		data += 'page=' + 1;

		location.href = data;
	}).siblings('input[type=text]').keyup(function(e) {
		// 回车提交
		var k = e.keyCode ? e.keyCode : e.which ? e.which : e.charCode;
        if(k == 13){
            $("#search").click();
            e.preventDefault();
        }
	});


})




function c(v){if(typeof console != 'undefined') console.log(v)}

/**
 * php strtr 2个参数版
 * @param  {string} str   
 * @param  {object} assoc 
 * @return {string}       
 */
function strtr(str, assoc){
	for(var k in assoc){
		str = str.replace(new RegExp(k, 'g'), assoc[k]);
	}

	return str;
}

/**
 * layer.tips
 * @param  {string} msg 
 * @param  {string} id  '#id'
 * @return {[type]}     [description]
 */
function _tips(msg, id){
	layer.tips(msg, id, {tips:[2,'#3fa7e9'], time:2333});
	$(id).focus();
}
/**
 * layer.msg
 * @param  {string} msg  
 * @param  {int} time ms
 * @return {[type]}      
 */
function _msg(msg, time, func){
	if(typeof time =='function'){
		layer.msg(msg, {time:2000}, time);
	}else if(typeof func == 'function'){
		layer.msg(msg, {time: time || 2000}, func);
	}else{
		layer.msg(msg, {time: time || 2000});
	}
}

function getCookie(name){
	var value = '',
		search = name + '=';
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(';', offset);
			if (end == -1) {
				end = document.cookie.length;
			}
			value = unescape(document.cookie.substring(offset, end))
		}
	}
	return value;
}

function setCookie(name, value, days) {
	var date = new Date();
	var d = days || 1;
	date.setDate(date.getDate() + d);
	document.cookie = name + "=" + escape(value) + "; expires=" + date.toGMTString();
}

//加法函数，用来得到精确的加法结果 
//说明：javascript的加法结果会有误差，在两个浮点数相加的时候会比较明显。这个函数返回较为精确的加法结果。 
//调用：accAdd(arg1,arg2) 
//返回值：arg1加上arg2的精确结果
function accAdd(arg1,arg2){ 
	var r1,r2,m; 
	try{r1 = arg1.toString().split(".")[1].length}catch(e){r1 = 0};
	try{r2 = arg2.toString().split(".")[1].length}catch(e){r2 = 0};
	m = Math.pow(10,Math.max(r1,r2)) 
	return (arg1*m+arg2*m)/m;
}

//减法函数，用来得到精确的减法结果 
//说明：javascript的减法结果会有误差，在两个浮点数相加的时候会比较明显。这个函数返回较为精确的减法结果。 
//调用：accSubtr(arg1,arg2) 
//返回值：arg1减去arg2的精确结果 
function accSubtr(arg1,arg2){
	var r1,r2,m,n;
	try{r1=arg1.toString().split(".")[1].length}catch(e){r1=0}
	try{r2=arg2.toString().split(".")[1].length}catch(e){r2=0}
	m=Math.pow(10,Math.max(r1,r2));
	//动态控制精度长度
	n=(r1>=r2)?r1:r2;
	return ((arg1*m-arg2*m)/m).toFixed(n);
} 


//乘法函数，用来得到精确的乘法结果 
//说明：javascript的乘法结果会有误差，在两个浮点数相乘的时候会比较明显。这个函数返回较为精确的乘法结果。 
//调用：accMul(arg1,arg2) 
//返回值：arg1乘以arg2的精确结果 
function accMul(arg1,arg2) { 
	var m=0,s1=arg1.toString(),s2=arg2.toString(); 
	try{m+=s1.split(".")[1].length}catch(e){} 
	try{m+=s2.split(".")[1].length}catch(e){} 
	return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m) 
} 

//除法函数，用来得到精确的除法结果 
//说明：javascript的除法结果会有误差，在两个浮点数相除的时候会比较明显。这个函数返回较为精确的除法结果。 
//调用：accDiv(arg1,arg2) 
//返回值：arg1除以arg2的精确结果 
function accDiv(arg1,arg2){ 
	var t1=0,t2=0,r1,r2; 
	try{t1=arg1.toString().split(".")[1].length}catch(e){} 
	try{t2=arg2.toString().split(".")[1].length}catch(e){} 
	with(Math){ 
		r1=Number(arg1.toString().replace(".","")) 
		r2=Number(arg2.toString().replace(".","")) 
		return (r1/r2)*pow(10,t2-t1); 
	} 
} 
