<?php
require_once APPPATH.'common/common.php';
require_once APPPATH.'services/Common_Service.php';

class Admin_Controller extends CI_Controller{
	// 静态资源路径
	public $static_path;
	// 页面title
	public $title;
	// 当前页使用到的样式完整路径 由子类指定
	public $style_path = array();
	// 当前页使用到的js完整路径 由子类指定
	public $script_path = array();
	// ci和ec的权限映射关系
	public $auth_map;
	// 默认载入当前控制器服务
	public $service;
	// 日志
	public $syslog;

	public function __construct(){
		parent::__construct();

		$this->load->library('session');
		$this->load->driver('cache', array('adapter' => 'apc', 'backup' => 'file'));
		$this->load->helper('url');
		$this->load->language('common');
		$this->static_path = base_url() . 'static/admin/';
		$this->title = '后台管理系统';
		$this->auth_map = include APPPATH . 'libraries/auth_map.php';

		$action = $this->uri->segment(2);
		$this->service = $this->load_service($action);
		$this->syslog  = $this->load_service('log');

		// 权限验证
		$path = $this->get_acm();// 控制器/方法
		// 除了login以外都需要权限验证
		if(!in_array($path, array('login/index', 'login/out'))){
			if(!$this->session->userdata('action_list')) redirect(siteurl('login'));
			if(!$this->has_priv($path)) exit('Access Denied');
		}
	}
	
	/**
	 * 加了一层service用于业务逻辑处理,控制器不直接调模型方法，模型只返回数据供serivice处理
	 * 命名:控制器_Service.php
	 * @return instance
	 */
	public function load_service($name){
		$name = ucfirst($name);
		$service = $name . '_Service';
		$service_file = APPPATH . 'services/' . $service . '.php';
		if(file_exists($service_file)){
			require_once $service_file;
			return $service::get_instance();
		}

		return false;
	}

	/**
	 * 返回当前控制器/方法?后面的搜索参数数组
	 * @return array 
	 */
	function get_search_param(){
		if(empty($_SERVER['QUERY_STRING'])) return array();

		parse_str($_SERVER['QUERY_STRING'], $arr);
		
		return $arr;
	}

	/**
	 * 返回当前action/method, method默认为index
	 * @return string
	 */
	public function get_acm(){
		return $this->uri->segment(2) . '/' . $this->uri->segment(3, 'index');
	}

	/**
	 * 权限判断
	 * @param  string  $priv 控制器/方法，会和ec的权限名进行映射判断
	 * @return boolean	   
	 */
	public function has_priv($priv){
		// 框架页
		if($priv == 'info/index') return true;

		$action = $this->session->userdata('action_list');
		if(is_string($action) && $action == 'all') return true;

		// 兼容ec
		$priv = isset($this->auth_map[$priv]) ? $this->auth_map[$priv] : $priv;
		$priv = strtolower($priv);

		return in_array($priv, $action);
	}

	
	/**
	 * 生成验证码
	 */
	public function create_captcha() {
		$this->load->helper('captcha');
		$background_color = array(array(141, 238, 238), array(255, 238, 238), array(118, 238, 0), array(238, 230, 133));
		$bg_color = array_rand($background_color);
		$vals = array(
			'img_path' => './static/captcha/',
			'img_url' => 'http://www.mobilezmq.com/static/captcha',
			'img_width' => '120',
			'img_height' => 30,
			'expiration' => 7200,
			'word_length' => 4,
			'font_size' => 6,
			'img_id' => 'captcha_image',
			'pool' => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
			'colors' => array(
				'background' => $background_color[$bg_color],
				'border' => array(255, 255, 255),
				'text' => array(0, 0, 0),
				'grid' => array(0, 255, 255)
			)
		);
		$cap = create_captcha($vals);
		return $cap; 
		//$this->session->set_userdata('captcha',$word);
		//return $cap;
	}
	
}