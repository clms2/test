<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_model extends CI_Model{

	public function get_regions(){
		$data = $this->db
					->select('region_id,parent_id,region_name')
					->from('region')
					->where(array('region_id !='=>1))
					->get()
					->result_array();

		return $this->get_menu_tree($data);
	}

	// todo.. 改成迭代 不用递归
	private function deal_regions($data){
		$result = array();

		foreach ($data as $d) {
			// 
			if(!isset($result[$d['region_type']])){
				$result[$d['region_type']] = array(
					'region_id' => $d['region_id'],
					'region_name' => $d['region_name']
				);
			}else{

			}
		}

		return $result;
	}

    private function get_menu_tree ($arrcat, $parent_id = 1 ) {
    	$arrtree = array ();
    	if (empty ( $arrcat ))
    		return false;
    	foreach ( $arrcat as $key => $value ) {
    		if ($value ['parent_id'] == $parent_id) {
    			unset ( $arrcat [$key] ); // 注销当前节点数据，减少已无用的遍历
    			$rid = $value['region_id'];
    			$value ['child'] = $this->get_menu_tree ($arrcat, $rid);
    			if (empty($value ['child'])) { unset($value['child']);}
    			// 无需返回的数据
    			unset($value['region_id'], $value['parent_id']);
    			$arrtree [$rid] = $value ;
    		}
    			
    	}
    	return $arrtree;
    }

    // 获取支付方式
    public function get_payment(){
    	return $this->db
    				->select('pay_id,pay_name')
    				->from('payment')
    				->where(array('enabled' => 1, 'is_cod' => 0))
    				->get()
    				->result_array();
    }

}