<?php 
// 用户账户
defined('BASEPATH') OR exit('No direct script access allowed');

class Finance_model extends CI_Model{

	public function __construct(){
		parent::__construct();

	}

	function get_finance_log($where, $field = '*'){

		return $this->db
					->select($field)
					->from('cw_reconc_log')
					->where($where)
					->get()
					->result_array();
	}
}