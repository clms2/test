<?php 
// 管理员管理
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminUser_model extends CI_Model{

	public function __construct(){
		parent::__construct();

	}

	public function get_user_list($param = array()){
		$offset = !empty($param['offset']) ? $param['offset'] : 0;
		$pagesize = !empty($param['pagesize']) ? $param['pagesize'] : 15;
		$where = empty($param['where']) ? array() : $param['where'];

		return $this->db
					->select('a.user_id,a.user_name,a.status,a.mobile,a.last_login,a.last_ip,a.add_time,a.jxs_id,r.role_name,r.role_id')
					->from('admin_user as a')
					->join('role as r', 'a.role_id=r.role_id', 'left')
					->where($where)
					->limit($pagesize, $offset)
					->get()
					->result_array();
	}

	public function get_user_by_id($id, $fields){
		return $this->db
					->select($fields)
					->from('admin_user')
					->where('user_id', $id)
					->get()
					->row_array();

	}

	public function get_user_by_name($name, $fields){
		return $this->db
					->select($fields)
					->from('admin_user')
					->where('user_name', $name)
					->get()
					->row_array();

	}

	public function update_user_info($uid, $data){
		
		return $this->db->update('admin_user', $data, array('user_id'=> $uid));
	}

	/**
	 * 获取所有角色
	 * @param string $field 需要的字段，多个用,隔开
	 * @param array $where 
	 * @return array field为单个返回：array(role_id => $field)
	 * @return array field为多个返回：array(role_id => array(field1 => field1_value,field2 => field2_value))
	 */
	public function get_role($field = 'role_name', $where = array()){
		$res = $this->db
					->select("role_id,$field")
					->from('role')
					->where($where)
					->get()
					->result_array();
		$ret = array();
		// 一个字段
		if(strpos($field, ',') === false){
			foreach ($res as $r) {
				$ret[$r['role_id']] = $r[$field];
			}
		}
		// 多个字段
		else{
			$field = explode(',', $field);
			foreach ($res as $r) {
				foreach ($field as $f) {
					$ret[$r['role_id']][$f] = $r[$f];
				}
			}
		}

		return $ret;
	}

	/**
	 * 获取所有权限列表
	 * @return array array(action_id=>array(action_code=>goods,sons=>array(action_id => array(action_code=>code, action_desc => desc),..)))
	 */
	public function get_all_permission(){
		$res = $this->db
					->select('action_id,parent_id,action_code')
					->from('admin_action')
					->get()
					->result_array();

		$this->load->language('permission');
		$ret = array();
		$desc = '';
		foreach ($res as $r) {
			// if(!$this->lang->line($r['action_code'])) continue;
			$desc = $this->lang->line($r['action_code']);
			if($r['parent_id'] === '0'){
				$ret[$r['action_id']]['action_code'] = $r['action_code'];
				$ret[$r['action_id']]['action_desc'] = $desc;
				// 下面写法是错的 数据库记录如果小类在大类上面会覆盖
				// $ret[$r['action_id']] = array(
				// 	'action_code' => $r['action_code'],
				// 	'action_desc' => $desc
				// );
			}else{
				$ret[$r['parent_id']]['sons'][$r['action_id']] = array(
					'action_code' => $r['action_code'],
					'action_desc' => $desc
				);
			}
		}

		return $ret;
	}

	/**
	 * 获取所有子权限
	 * @return array array(action_id => action_code)
	 */
	public function get_sons_permission($isparent = false){
		if($isparent){
			$where = 'parent_id';
		}else{
			$where = 'parent_id !=';
		}
		$res = $this->db
					->select('action_id,action_code')
					->from('admin_action')
					->where($where, 0)
					->get()
					->result_array();
		$ret = array();
		foreach ($res as $r) {
			$ret[$r['action_id']] = $r['action_code'];
		}

		return $ret;
	}

	public function get_parent_permission(){
		return $this->get_sons_permission(true);
	}
}