<?php 
// 会员管理
defined('BASEPATH') OR exit('No direct script access allowed');

class Member_model extends CI_Model{

	public function __construct(){
        parent::__construct();

    }

    public function get_member_list($param = array()){
		$offset = !empty($param['offset']) ? $param['offset'] : 0;
		$pagesize = !empty($param['pagesize']) ? $param['pagesize'] : 15;
		$order = !empty($param['order']) ? $param['order'] : 'user_id asc';
		$where = empty($param['where']) ? array() : $param['where'];

		return $this->db
					->select('user_id,status,user_name,pay_points,last_login,reg_time,visit_count,jxsid,card_num,source')
					->from('users')
					->where($where)
					->order_by($order)
					->limit($pagesize, $offset)
					->get()
					->result_array();
	}

	// 充值和提现申请
	public function get_refund_list($param = array()){
		$offset = !empty($param['offset']) ? $param['offset'] : 0;
		$pagesize = !empty($param['pagesize']) ? $param['pagesize'] : 15;
		$order = !empty($param['order']) ? $param['order'] : 'a.add_time desc';
		$where = empty($param['where']) ? array() : $param['where'];

		return $this->db
					->select('a.id,a.admin_user,a.amount,a.add_time,a.paid_time,a.process_type,a.admin_note,a.user_note,a.is_paid,a.payment,u.user_name')
					->from('user_account as a')
					->join('users as u', 'a.user_id = u.user_id', 'join')
					->where($where)
					->order_by($order)
					->limit($pagesize, $offset)
					->get()
					->result_array();
	}

	public function get_user_by_id($id){
		return $this->db
					->select('u.user_id,u.sex,u.user_name,u.pay_points,addr.consignee,addr.address_id,addr.province,addr.city,addr.district,addr.address,addr.mobile')
					->from('users as u')
					->join('user_address as addr', 'u.address_id = addr.address_id', 'left')
					->where('u.user_id', $id)
					->get()
					->row_array();

	}

}