<?php 
// 物品
defined('BASEPATH') OR exit('No direct script access allowed');

class Goods_model extends CI_Model{

	public function __construct(){
		parent::__construct();

	}

	// 获取所有套餐名 供下拉选择
	function get_item_set(){

		return $this->db
					->select('goods_id,goods_simple_name')
					->from('goods')
					->where(array('extension_code' => 'virtual_card', 'is_real' => 0))
					->get()
					->result_array();
	}

	// 获取套餐对应的桶装水数量
	function get_item_set_num($where){

		return $this->db
					->select('goods_id,content')
					->from('item_hd')
					->where($where)
					->get()
					->result_array();
	}

	function get_item_by_id($id, $field){

		return $this->db
					->select($field)
					->from('goods')
					->where('goods_id', $id)
					->get()
					->row_array();
	}

}