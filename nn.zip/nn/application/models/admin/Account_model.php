<?php 
// 用户账户
defined('BASEPATH') OR exit('No direct script access allowed');

class Account_model extends CI_Model{

	public function __construct(){
		parent::__construct();

	}

	function add_account_log($data){
		$this->db->insert('account_log', $data);

		return $this->db->insert_id();
	}

}