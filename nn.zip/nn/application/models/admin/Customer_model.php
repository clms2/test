<?php 
// 经销商
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_model extends CI_Model{

	public function __construct(){
		parent::__construct();

	}

	/**
	 * 获取所有经销商对应关系列表
	 * @return array array(jxs_id=>array(title=>title,child=>array(jxs_id => array(title=>title),..)))
	 */
	function get_all_customer_map(){
		$res = $this->db
					->select('id,topqudao,title')
					->from('ts_customers')
					->get()
					->result_array();

		$ret = array();
		$desc = '';
		foreach ($res as $r) {
			if(empty($r['topqudao'])){
				$ret[$r['id']]['title'] = $r['title'];
			}else{
				$ret[$r['topqudao']]['child'][$r['id']]['title'] = $r['title'];
			}
		}

		return $ret;
	}

	function get_jxs_by_id($id, $field){

		return $this->db
					->select($field)
					->from('ts_customers')
					->get()
					->row_array();
	}

}