<?php 
// 水卡管理
defined('BASEPATH') OR exit('No direct script access allowed');

class WaterCard_model extends CI_Model{

	public function __construct(){
		parent::__construct();
	}

	function get_water_card_list($param){
		$offset   = !empty($param['offset']) ? $param['offset'] : 0;
		$pagesize = !empty($param['pagesize']) ? $param['pagesize'] : 15;
		$order    = !empty($param['order']) ? $param['order'] : 'b.id desc';
		$where    = empty($param['where']) ? array() : $param['where'];
		$where_in = empty($param['where_in']) ? array() : $param['where_in'];
		$like     = empty($param['like']) ? array() : $param['like'];

		$this->db
			->select('b.ID as id,b.wl,t.topqudao,b.to_id,t.title,t1.title as fxs_name,t1.id as fxs_id,b.sellto,u.user_name,b.status,b.sellday,item.remain_num,b.use_flag,b.act_time,b.par_time,g.goods_simple_name,b.real_price')
			->from('bianma_ as b')
			->join('users u', 'b.sellto = u.user_id', 'left')
			->join('ts_customers as t', 'b.to_id = t.id', 'left')
			->join('ts_customers as t1', 't.topqudao = t1.id', 'left')
			->join('bianma_item as item', 'b.wl=item.wl and item.item_id in(171,274)', 'left')
			->join('goods g', 'b.uid_type=g.goods_id', 'left')
			->where($where);

		foreach ($where_in as $field => $value) {
			if(!empty($value))
				$this->db->where_in($field, $value);
		}
		if(!empty($like)){
			// 不转义,否则会出现奇怪的 ESCAPE '!'
			$this->db->like($like, '', 'both', false);
		}


		return $this->db
					->order_by($order)
					->limit($pagesize, $offset)
					->get()
					->result_array();
	}

	function get_card_by_id($id){

		return $this->db
					->select('b.id,b.use_flag,b.wl,b.uid_money,b.real_price,b.uid_type,b.is_point,b.to_id,t.topqudao,b.par_time')
					->from('bianma_ as b')
					->join('ts_customers as t', 'b.to_id = t.id', 'left')
					->where('b.id', $id)
					->get()
					->row_array();
	}

}