<?php 
// 日志
defined('BASEPATH') OR exit('No direct script access allowed');

class Log_model extends CI_Model{

	public function __construct(){
		parent::__construct();

	}

	private function insert_log($table, $data = array()){
		$default = array(
			'log_time'   => time(),
			'user_id'    => $this->session->userdata('uid'),
			'ip_address' => $_SERVER['REMOTE_ADDR']
		);

		$this->db->insert($table, $default + $data);

		return $this->db->insert_id();
	}

	function add_admin($msg){

		return $this->insert_log('admin_log', array('log_info' => $msg));
	}

	function add_admin_card($wl, $msg){

		return $this->insert_log('admin_card_log', array('wl' => $wl, 'log_info' => $msg));
	}
}