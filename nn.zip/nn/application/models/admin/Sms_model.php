<?php 
// 短信管理
defined('BASEPATH') OR exit('No direct script access allowed');

class Sms_model extends CI_Model{

	const SMS_SEND_URL = 'http://sms.chanzor.com:8001/sms.aspx';
	// 短信余额接口
	const SMS_REMAIN_URL = 'http://sms.chanzor.com:8001/sms.aspx';
	const UNAME = 'zhuomaquan';
	const PWD = 'zhuomaquan123';
	// 同步短信到第三方后台的配置数组
	private $cfg_sync = array(
		// 第三方登陆地址
		'url_login' => 'http://web.chanzor.com:8080/Account/LogOn',
		// 第三方添加短信地址
		'url_addmsg' => 'http://web.chanzor.com:8080/FreeAudit/Create',
		// 添加短信的referer
		'url_addmsg_referer' => 'http://web.chanzor.com:8080/FreeAudit/Create'
	);

	public function __construct(){
        parent::__construct();

    }

    /**
     * 发送短信
     * @param  string $tel 
     * @param  string $msg 
     * @return boolean
     */
	public function send($tel, $msg, $sendtime = ''){
		$data = array(
			'action'   => 'send',
			'userid'   => '',
			'account'  => self::UNAME,
			'password' => self::PWD,
			'mobile'   => $tel,
			'sendTime' => $sendtime,
			'content'  => $msg
		);

		$result = $error = curl_send(self::SMS_SEND_URL, $data);
		$result = $this->parse_data($result);

		// curl请求出错,使用curl错误信息
		if(empty($result['returnstatus'])){
			$result['returnstatus']  = 'Faild';
			$result['message']       = $error;
			$result['successCounts'] = 0;
		}
		// 短信发送出错,使用对方回复的错误信息
		else if($result['returnstatus'] == 'Faild'){
			$result['returnstatus'] = !empty($result['message']) ? $result['message'] : '其他错误';
		}

		// todo.. 多个手机号变为多条记录 而不是存一个字段
		$insert = array(
			'sendcell'  => $tel,
			'sendstate' => $result['returnstatus'],
			'sendmsg'   => $msg,
			'ip'        => $_SERVER['REMOTE_ADDR'],
			'USERID'    => $this->session->userdata('uid')
		);

		$ret = array();
		if(!$this->db->insert('sms_log', $insert)){
			$error = $this->db->error();
			$ret['success'] = -1;
			$ret['msg'] = '数据插入失败,'.addslashes($error['message']);
			$ret['count'] = $result['successCounts'];
		}else{
			$ret['success'] = $result['returnstatus'] == 'Faild' ? -1 : 1;
			$ret['msg'] = $result['returnstatus'];
			$ret['count'] = $result['successCounts'];
		}

		return $ret;
	}

	/**
	 * 获取短信列表
	 * @param  array  $param array(offset=>偏移量,pagesize=>每页数,筛选字段=>内容)
	 * @return array
	 */
	public function get_sms_list($param = array()){
		$offset = !empty($param['offset']) ? $param['offset'] : 0;
		$pagesize = !empty($param['pagesize']) ? $param['pagesize'] : 15;
		$where = !empty($param['where']) ? $param['where'] : array();

		return $this->db
					->select('sendcell,sendstate,sendmsg,sendtime')
					->from('sms_log')
					->where($where)
					->order_by('id', 'desc')
					->limit($pagesize, $offset)
					->get()
					->result_array();
	}

	/**
	 * 获取短信模板列表
	 * @param  array  $param array()
	 * @return array  
	 */
	public function get_tpl_data($param = array()){
		return $this->db
					->select('*')
					->from('sms_tpl')
					->where($param)
					->get()
					->result_array();
	}

	/**
	 * 根据id修改短信模板
	 * @param  int $id   
	 * @param  array  $data key=>value
	 * @return [type]       
	 */
	public function modify_tpl_by_id($id, $data = array()){
		return $this->db->update('sms_tpl', $data, array('id' => $id));
	}

	/**
	 * 添加模板
	 * @param array $data key=>value
	 */
	public function add_tpl($data){
		$this->db->insert('sms_tpl', $data);
		return $this->db->insert_id();
	}

	/**
	 * 获取可发送短信剩余数
	 * @return int 
	 */
	public function sms_remain_num(){
		// action=overage&userid=12&account=账号&password=密码
		$data = array(
			'action' => 'overage',
			'userid' => '',
			'account' => self::UNAME,
			'password' => self::PWD
		);

		$ret = curl_send(self::SMS_REMAIN_URL, $data);
		$ret = $this->parse_data($ret);
		
		return isset($ret['overage']) ? $ret['overage'] : 'error';
	}

	/**
	 * 短信模板同步
	 * @param string $msg 短信内容 @占位
	 * @param string $remark 显示在第三方平台列表页的备注信息
	 * @return boolean 
	 */
	public function sms_sync($msg, $remark = ''){
		if(!$this->sms_syncable()) return false;
		// 判断cookie是否已过期
		$ct = file_get_contents($this->cfg_sync['cookiefile']);
		$need_login = false;
		if(!empty($ct)){
			preg_match('#\d{10}#sU', $ct, $m);
			if(empty($m[0])){
				$need_login = true;
			}else if((time() - 10) > $m[0]){
				$need_login = true;
			}
		}else{
			$need_login = true;
		}
		if($need_login){
			$this->sms_sync_login();
		}

		return $this->sms_sync_addmsg($msg, $remark);
	}

	/**
	 * 判断是否可进行同步操作
	 * @return boolean 
	 */
	private function sms_syncable(){
		// /application/cache/cookie.txt
		$file = APPPATH . 'cache' . DIRECTORY_SEPARATOR . 'cookie.txt';
        if(!@touch($file)) {
        	return false;
        }
        $this->cfg_sync['cookiefile'] = $file;

        $this->sms_sync_init();
        return true;
	}

	// 设置crulopt,不能放在开头定义，有用到变量
	private function sms_sync_init(){
		$this->cfg_sync['curlopt'] = array(
			CURLOPT_HTTPHEADER => array(
				'Accept: */*',
		        'Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
		        'Accept-Encoding: gzip, deflate',
		        'Connection: keep-alive',
		        'Content-Type: application/x-www-form-urlencoded',
		        'Host: web.chanzor.com:8080',
		        'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0'
			),
			// 超时短不影响其他操作
			CURLOPT_TIMEOUT => 3,
			CURLOPT_COOKIEFILE => $this->cfg_sync['cookiefile'],
			CURLOPT_COOKIEJAR => $this->cfg_sync['cookiefile'],
			CURLOPT_FOLLOWLOCATION => 1
		);
	}

	// 登陆，获取cookie
	private function sms_sync_login(){
		$data = array(
			'UserName' => self::UNAME,
			'PassWord' => self::PWD,
			'RememberMe' => 'true',
			'image.x' => mt_rand(2, 170),// 登陆按钮的点击位置
			'image.y' => mt_rand(2, 48)
		);
		curl_send($this->cfg_sync['url_login'], $data, $this->cfg_sync['curlopt']);
	}

	// 添加短信到第三方平台
	private function sms_sync_addmsg($msg, $remark = ''){
		$data = array(
			'Remark'           => $remark,
			'Text'             => $msg,
			'X-Requested-With' => 'XMLHttpRequest'
		);
		$this->cfg_sync['curlopt'][CURLOPT_HTTPHEADER][] = 'X-Requested-With: XMLHttpRequest';
		$this->cfg_sync['curlopt'][CURLOPT_REFERER] = $this->cfg_sync['url_addmsg_referer'];

		$ret = curl_send($this->cfg_sync['url_addmsg'], $data, $this->cfg_sync['curlopt']);

		return strpos($ret, '添加成功') !== false;
	}

	/**
	 * 转换接口返回的xml数据为数组
	 * @param  string $data xml string
	 * @return array       
	 */
	private function parse_data($data){
		$data = simplexml_load_string($data);

		return json_decode(json_encode($data), 1);
	}

}