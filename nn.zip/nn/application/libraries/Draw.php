<?php

/**
 * 抽奖类
 */
class Draw{
    
    protected $percentage; //初始化中奖率
    protected $reward; //奖品数组
    protected $change_method; //中奖率变化方式 为0 表示不变化 直至奖品发完 1表示按时间变化  
    protected $remain_num;
    protected $total_num;
    protected $coefficient; //中奖率变化系数
    /**
     * 构造函数
     */
    public function __construct($percentage='0',$reward=array(),$change_method=0,$coefficient=0) {
        $this->percentage = $percentage;
        $this->reward = $reward;
        $this->change_method = $change_method;
        $this->remain_num = 0;
        $this->total_num = 0;
        $this->coefficient = $coefficient;
    }
    
    /**
     * 抽奖
     */
    public function get_result(){
        //判断奖品数是否有剩余
        $result = $this->get_reward_num($this->reward);
        if($result['reward_num'] <= 0){
            return false; //本月奖品已发完  不再考虑中奖概率
        }
        
        //判断是否根据时间变化 调整概率
        if($this->change_method == 1){
            $this->percentage = $this->get_percentage($this->percentage);
        }
        
        //判断用户是否中奖
        $rand = rand(1,100);
        if($this->percentage >= $rand){
            //中奖
            return true;
        }else{
            //未中奖
            return false;
        }
    }
    
    private function get_reward_num($reward_list){
        array_map(function($item){
            $this->remain_num += is_object($item) ? $item->remain_num : $item['remain_num'];
            $this->total_num += is_object($item) ? $item->total_num : $item['total_num'];
        }, $reward_list);
        return array('remain_num'=>$this->remain_num,'total_num'=>$this->total_num);
    }
    
    private function get_percentage($percentage){
        /*
         * @todo 待优化
         * 新的中奖率 = 初始化中奖率 + （当前日期/当月总天数）* 100 * 中奖系数
         */
        //获取当前天数 和 本月总天数
        $total_days = date('t');
        $current_day = date('d');
        $new_percentage = $percentage + ($current_day/$total_days)*100*$this->coefficient;
        return $new_percentage>100 ? 100 : $new_percentage;
        
    }
}
?>
