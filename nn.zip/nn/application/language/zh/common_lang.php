<?php 
// 公共描述
$lang['tel'] = '手机号';
$lang['status'] = '状态';
$lang['succ'] = '成功';
$lang['fail'] = '失败';
$lang['search'] = '搜索';
$lang['content'] = '内容';
$lang['uname'] = '用户名';

// 按钮描述
$lang['btn_add'] = '添加';
$lang['btn_modify'] = '修改';
$lang['btn_submit'] = '提交';
$lang['btn_confirm'] = '确定';
$lang['btn_reset'] = '清空';


// 公共错误提示
$lang['err_system'] = '系统错误，请联系管理员';
$lang['xss_tip'] = '发现非法字符，请调整或联系管理员';
$lang['file_readonly'] = '写入文件{file}失败!';
$lang['err_tel'] = '请输入正确的手机号';