<?php 
// 登陆相关描述 admin/login
$lang['login_tit'] = '登陆管理后台';
$lang['login_btn'] = '登陆';
$lang['login_rem'] = '记住我';
$lang['login_uname_holder'] = '请输入账号';
$lang['login_pwd_holder'] = '请输入密码';
