<?php 
// 短信功能相关描述

// 短信列表 sms/index
$lang['sms_tit'] = '短信管理';
$lang['sms_remain_num'] = '剩余数：';
$lang['sms_send_content'] = '发送内容';
$lang['sms_send_time'] = '发送时间';

// 发送短信 sms/send
$lang['sms_recive_tel'] = '接收手机号';
$lang['sms_recive_tel_tip'] = '(多个手机号码用半角逗号分开)';

// 通知模板 sms/template
$lang['template_select_tpl'] = '请选择短信模板';
$lang['template_name'] = '模板名';
$lang['template_name_holder'] = '如：验证码模板';
$lang['template_endesc'] = '英文简称';
$lang['template_endesc_holder'] = '如：verify_code';
$lang['template_company_type'] = '企业类型';
$lang['template_company_type_0'] = '卓玛泉';
$lang['template_company_type_1'] = '我爱健康';
$lang['template_content'] = '模板内容';
$lang['template_content_holder'] = '显示数量的地方的用%s占位';
$lang['template_sync'] = '同步选项';
$lang['template_sync_to_open'] = '同步到短信平台';


// 错误提示
$lang['err_key_exists'] = '英文简称已存在，请换个简称';
