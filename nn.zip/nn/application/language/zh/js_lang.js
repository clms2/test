// js错误提示文件
if(!window.$lang){
	window.$lang = {
		err_system: '系统错误，请联系管理员',
		tip_not_changed: '内容没有变化哦~',
		tip_confirm: '确定要修改嘛？',
		tip_modify_succ: '修改成功！',
		tip_operate_succ: '操作成功',
		// 通知模板管理
		template:{
			empty_tplname: '请输入模板名',
			empty_endesc: '请输入英文简称',
			empty_content: '请输入模板内容',
			sync_succ:'，已同步到短信平台',
		},
		login:{
			empty_uname:'请输入用户名',
			empty_pwd:'请输入密码',
		},
	};
}

