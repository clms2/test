<?php 
// 短信模板相关
$lang['bind']                   = '水卡绑定模板';
$lang['order_subscribe']        = '配送订单模板';
$lang['order']                  = '订单模板';
$lang['find']                   = '查询金额模板';
$lang['reg']                    = '注册短信模板';
$lang['findpwd']                = '找回密码模板';
$lang['regsucess']              = '注册成功模板';
$lang['findpwdsucess']          = '重置密码模板';
$lang['paypoint']               = '积分商城兑换模板';
$lang['sms_tpl']                = '通知模板';
$lang['update_success']         = '模板更新成功！';
$lang['update_failed']          = '模板更新失败！';
$lang['chief']                  = '爱大厨活动模板';
$lang['weixin_order_subscribe'] = '微信下配送单送水模板';
$lang['order_subscribe_update'] = '配送订单修改模板';
$lang['order_subscribe_revoke'] = '配送订单撤消模板';
$lang['weixin_order']           = '微信下单送礼模板';
$lang['consignee_order']        = '发货模板';
$lang['out_paypoint']           = '撤销兑换模板';
$lang['hjf_sendcode_bind']      = '绑定汇积分短信验证码';
$lang['hjf_out_paypoint']       = '转入汇积分成功模板';
$lang['hjf_in_paypoint']        = '转出汇积分成功模板';
$lang['hjf_bind_succeed']       = '绑定汇积分成功模板';
$lang['hjf_sendcode_pay']       = '转入汇积分短信验证码';