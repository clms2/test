<?php 
/* 权限管理的一级分组 */
$lang['goods'] = '商品管理';
$lang['cms_manage'] = '文章管理';
$lang['users_manage'] = '会员管理';
$lang['priv_manage'] = '权限管理';
$lang['sys_manage'] = '系统设置';
$lang['order_manage'] = '订单管理';
$lang['promotion'] = '促销管理';
$lang['email'] = '邮件管理';
$lang['templates_manage'] = '模板管理';
$lang['db_manage'] = '数据库管理';
$lang['sms_manage'] = '短信管理';
$lang['coupons_manage'] = '卡券管理';
//商品管理部分的权限
$lang['goods_list'] = '商品列表';
$lang['goods_manage'] = '商品添加/编辑';
$lang['remove_back'] = '商品删除/恢复';
$lang['cat_manage'] = '分类添加/编辑';
$lang['cat_drop'] = '分类转移/删除';
$lang['attr_manage'] = '商品属性管理';
$lang['brand_manage'] = '商品品牌管理';
$lang['comment_priv'] = '用户评论管理';
$lang['goods_type'] = '商品类型';
$lang['tag_manage'] = '标签管理';
$lang['goods_auto'] = '商品自动上下架';
$lang['topic_manage'] = '专题管理';
$lang['virualcard'] = '水券套餐管理';
$lang['virualcard_add'] = '添加水券套餐';
$lang['again_virtual_card_list'] ='续卡套餐管理';
$lang['again_virtual_card_add'] ='添加续卡套餐';
$lang['picture_batch'] = '图片批量处理';
$lang['goods_export'] = '商品批量导出';
$lang['goods_batch'] = '商品批量上传/修改';
$lang['gen_goods_script'] = '生成商品代码';
$lang['suppliers_goods'] = '供货商商品管理';
$lang['goods_volume'] = '商品价格体系';
//文章管理部分的权限
$lang['article_cat'] = '文章分类管理';
$lang['article_manage'] = '文章内容管理';
$lang['shopinfo_manage'] = '网店信息管理';
$lang['shophelp_manage'] = '客服知识库';
$lang['vote_priv'] = '在线调查管理';
$lang['article_auto'] = '文章自动发布';

//会员信息管理
$lang['integrate_users'] = '会员数据整合';
$lang['sync_users'] = '同步会员数据';
$lang['users_manages'] = '会员添加/编辑';
$lang['users_drop'] = '会员删除';
$lang['user_rank'] = '会员等级管理';
$lang['feedback_priv'] = '会员留言管理';
$lang['surplus_manage'] = '会员余额管理';
$lang['account_manage'] = '会员账户管理';

$lang['users_list'] = '会员列表';
$lang['user_account'] = '充值和提现申请';




//权限管理部分的权限
$lang['admin_manage'] = '管理员添加/编辑';
$lang['admin_drop'] = '删除管理员';
$lang['allot_priv'] = '分派权限';
$lang['logs_manage'] = '管理日志列表';
$lang['logs_drop'] = '删除管理日志';
$lang['template_manage'] = '模板管理';
$lang['agency_manage'] = '办事处管理';
$lang['suppliers_manage'] = '供货商管理';
$lang['role_manage'] = '角色管理';

//系统设置部分权限
$lang['shop_config'] = '商店设置';
$lang['webcollect_manage'] = '网罗天下管理';
$lang['ship_manage'] = '配送方式管理';
$lang['payment'] = '支付方式管理';
$lang['shiparea_manage'] = '配送区域管理';
$lang['area_manage'] = '地区列表管理';
$lang['friendlink'] = '友情链接管理';
$lang['db_backup'] = '数据库备份';
$lang['db_renew'] = '数据库恢复';
$lang['flash_manage'] = '首页主广告管理'; //Flash 播放器管理
$lang['navigator'] = '自定义导航栏';
$lang['cron'] = '计划任务';
$lang['affiliate'] = '推荐设置';
$lang['affiliate_ck'] = '分成管理';
$lang['sitemap'] = '站点地图管理';

$lang['file_priv'] = '文件权限检验';
$lang['reg_fields'] = '会员注册项管理';
$lang['problem'] = '常见问题管理';

//订单管理部分权限
$lang['order_os_edit'] = '编辑订单状态';
$lang['order_ps_edit'] = '编辑付款状态';
$lang['order_ss_edit'] = '编辑发货状态';
$lang['order_edit'] = '添加编辑订单';
$lang['order_view'] = '查看未完成订单';
$lang['order_view_finished'] = '查看已完成订单';
$lang['repay_manage'] = '退款申请管理';
$lang['booking'] = '缺货登记管理';
$lang['sale_order_stats'] = '订单销售统计';
$lang['client_flow_stats'] = '客户流量统计';
$lang['delivery_view'] = '查看发货单';
$lang['back_view'] = '查看退货单';
$lang['order_info'] = "查看订单详细";

$lang['order_list'] = '订单列表';
$lang['order_query'] = '订单查询';
$lang['edit_order_print'] = '订单打印';
$lang['add_order'] = '添加订单';
$lang['sale_report_stats'] =  '销售报表';
$lang['invoice_list'] = '发票管理';
$lang['invoice_edit'] = '发票编辑';


//促销管理
$lang['snatch_manage'] = '夺宝奇兵';
$lang['bonus_manage'] = '红包管理';
$lang['card_manage'] = '祝福贺卡';
$lang['pack'] = '商品包装';
$lang['ad_manage'] = '广告管理';
$lang['gift_manage'] = '赠品管理';
$lang['auction'] = '拍卖活动';
$lang['group_by'] = '团购活动';
$lang['favourable'] = '优惠活动';
$lang['whole_sale'] = '批发管理';
$lang['package_manage'] = '超值礼包';

//邮件管理
$lang['attention_list'] = '关注管理';
$lang['email_list'] = '邮件订阅管理';
$lang['magazine_list'] = '杂志管理';
$lang['view_sendlist'] = '邮件队列管理';

//模板管理
$lang['template_select'] = '模板选择';
$lang['template_setup']  = '模板设置';
$lang['library_manage']  = '库项目管理';
$lang['lang_edit']       = '语言项编辑';
$lang['backup_setting']  = '模板设置备份';
$lang['mail_template']  = '邮件模板管理';

//数据库管理
$lang['db_backup']    = '数据备份';
$lang['db_renew']     = '数据恢复';
$lang['db_optimize']  = '数据表优化';
$lang['sql_query']    = 'SQL查询';


//短信管理
$lang['my_info']         = '账号信息';
$lang['sms_send']        = '发送短信';
$lang['sms_charge']      = '短信充值';
$lang['send_history']    = '发送记录';
$lang['charge_history']  = '充值记录 ';
$lang['sms_tpl'] 		  = '通知模板';

//水卡管理
$lang['water_card']      = '水卡管理';
$lang['water_card_list']    = '水卡列表';
$lang['batchCard_log_list']  = '水卡状态日志';
$lang['card_goods_list']  = '水卡物品列表 ';
$lang['card_batch_item'] = '水卡批量充值';
$lang['add_batchCard']    = '批量添加水卡';
$lang['business_card_activate']      = '激活电商卡';
$lang['card_loss']		= '挂失水卡';
$lang['add_card_item']		= '水卡充值';
$lang['card_unbound']		= '水卡解绑';
$lang['card_bind']		= '水卡绑定';
$lang['card_activate']		= '激活水卡';
$lang['bianma_csvadd']		= '批量生成水卡';
$lang['bianma_csvlist']		= '批量生成记录';
$lang['bianma_give']		= '水卡赠送配送统计';

//配送订单管理
$lang['water_order'] = '配送订单管理';
$lang['water_order_down']  = '配送订单下载';
$lang['water_order_query']  = '配送订单查询';
$lang['water_order_list']  = '配送订单列表';
$lang['water_order_add']  = '添加配送订单';
$lang['400_index']  = '客服工单';
//$lang['water_report']  = '全局出水量报表';
//$lang['water_give_report']  = '赠送出水量报表';






//经销商管理

$lang['19_jxs']	= '经销商管理';
$lang['jxs_list'] = '经销商列表';  //经销商管理
$lang['cxs_list'] = '分销商管理';  //分销商管理
$lang['divide_card'] = '分配水卡';  //分配水卡
$lang['active_card'] = '激活水卡';  //激活水卡
$lang['jxs_money_log'] = '经销商财务日志';  //经销商财务日志
$lang['divide_card_log'] = '分配水卡日志';  //分配水卡日志
$lang['active_card_log'] = '激活水卡日志';  //激活水卡日志
$lang['jxs_list_info']		=  '个人资料';
$lang['jxs_return_money'] = '经销商返利日志';  //分配水卡日志
$lang['jxs_report_d'] = '经销商日报';  //激活水卡日志
$lang['jxs_report_m']		=  '经销商月报';

$lang['cw_reconc_log']		=  '财务对账';
$lang['cw_reconc_log_edit']		=  '财务对账编辑';
$lang['jxs_ship_count'] = '经销商配送统计';
$lang['jxs_ship_money'] = '经销商配送费用管理';

/*积分商城 */
$lang['gift_hjf'] = '汇积分兑换列表';
$lang['order_gift_invalid'] = '积分兑换订单撤销';


/* 微商城 */
$lang['20_weixin']		= '微商城';
$lang['weixin_port']	 = '微信接口';
$lang['weixin_set']	 = '微信设置';
$lang['weixin_regmsg']  = '关注回复内容';
$lang['weixin_keywords'] = '关键词回复内容';
$lang['weixin_menu']	 = '自定义菜单';
$lang['weixin_bonus'] = '关注送红包';
$lang['weixin_point'] = '互动积分';

/* 邹静扩展功能 */
$lang['zjkzgn'] = '扩展功能';  
$lang['zjjxsfw'] = '经销商访问记录';  
$lang['scjxsewm'] = '生成经销商二维码';  
$lang['agency_reply'] = '经销商专属回复';
$lang['marketrecipient'] = '市场部收款管理'; 

$lang['coupons'] = '优惠券列表';
$lang['member_card'] = '会员卡列表';
$lang['share_permission'] = '领取卡券人员列表';
$lang['water_card_permission'] = '领取电子卡人员列表';
$lang['b2c_order'] = '天猫订单列表';
$lang['b2c_jd_order'] = '京东订单列表';