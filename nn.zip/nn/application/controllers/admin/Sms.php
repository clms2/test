<?php
// 短信管理
defined('BASEPATH') OR exit('No direct script access allowed');

class Sms extends Admin_Controller{

	public function __construct(){
		parent::__construct();

		$this->load->language('sms');
	}

	// 列表页
	public function index(){
		$this->title .= ' - 短信管理';
		$this->style_path = array($this->static_path . 'css/compiled/tables.css');
		$param = array();

		$tel = $this->input->get('tel');
		
		$data = array();
		$param = array('where' => array());

		$search_param = $this->get_search_param();
		$tel = !empty($search_param['tel']) ? $search_param['tel'] : '';
		if(!empty($tel) && preg_match('#^\d{11}$#', $tel)){
			$param['where']['sendcell'] = $tel;
			$data['tel'] = $tel;
		}

		$data['data'] = $this->service->get_sms_list($param);

		$data['pagelist'] = $this->service->get_pagelist(array(
			'table' => 'sms_log',
			'where' => $param['where']
		));

		// 短信剩余数
		// $data['left_num'] = $this->service->sms_remain_num();
		$data['left_num'] = '未获取';

		$this->load->view('admin/sms/index.html', $data);
	}

	// 发送短信
	public function send(){
		// 发送
		if(!empty($_POST)){
			$tel = $this->input->post('tel');
			$msg = $this->input->post('msg');

			if(empty($tel) || empty($msg)) exit('-1');
			$ret = array('code' => 1);

			$this->db->cache_delete('sms', 'index');

			ex($this->service->send($tel, $msg));
		}
		$this->style_path = array(
			$this->static_path . 'css/lib/font-awesome.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
		);

		$this->load->view('admin/sms/send.html');
	}

	// 短信通知模板列表
	public function template(){
		$data = $this->service->get_tpl_data();
		$this->load->language('sms_tpl');

		$this->style_path = array(
			$this->static_path . 'css/lib/font-awesome.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
		);

		// 用于点击下拉切换短信内容 id => content
		$tpl_map = array();
		// 将所有数据拼接成 company_type=>结果集
		$new_data = array();
		foreach ($data as $k => $arr) {
			// scene => desc
			if(isset($this->lang->language[$arr['scene']])){
				$arr['scene'] = $this->lang->language[$arr['scene']];
				$data[$k] = $arr;
			}
			// 不需要返回给客户端的字段
			$typeid = $arr['company_type'];
			unset($arr['company_type']);
			$new_data[$typeid][] = $arr;

			$tpl_map[$arr['id']] = $arr['content'];
		}
		$this->load->view('admin/sms/template.html', array(
			'data'    => $new_data,
			'tpl_map' => $tpl_map
		));
	}

	// 添加模板
	public function tpl_add(){
		$ret = array('code' => 1);
		$ct  = $old = $this->input->post('ct');
		$ct  = $this->security->xss_clean($ct);
		if($ct !== $old){
			$ret['code'] = -2;
			$ret['msg'] = $this->lang->line('xss_tip');
			ex($ret);
		}

		$tpl_name = $old_name = $this->input->post('tpl_name');
		$scene    = $old_scene = $this->input->post('scene');
		$scene    = preg_replace('#[^A-Za-z\_]#', '', $scene);
		$type     = $this->input->post('company_type');
		$syncable = $this->input->post('syncenable');

		if(empty($ct) || empty($tpl_name) || empty($scene) || $scene !== $old_scene || !in_array($type, array(1, 0))) exit('-1');
		$tpl_name = $this->security->xss_clean($tpl_name);
		if($tpl_name !== $old_name){
			$ret['code'] = -2;
			$ret['msg']  = $this->lang->line('xss_tip');
			ex($ret);
		}

		// 数组键不能重复
		$this->load->language('sms_tpl');
		if($this->lang->line($scene)){
			$ret['code'] = '-5';
			$ret['msg'] = $this->lang->line('err_key_exists');
			ex($ret);
		}

		// 写入语言文件 scene => desc
		$cfg = get_config();
		$file = APPPATH . 'language/' . $cfg['language'] . '/sms_tpl_lang.php';
		$lang_ct = "\r\n\$lang['$scene'] = '$tpl_name';";
		if(!file_put_contents($file, $lang_ct, FILE_APPEND)){
			$ret['code'] = '-4';
			$ret['msg'] = str_replace('{file}', 'sms_tpl_lang.php', $this->lang->line('file_readonly'));
			ex($ret);
		}

		// 插入数据库
		$id = $this->service->add_tpl(array(
			'type'         => 'sms',
			'scene'        => $scene,
			'company_type' => $type,
			'content'      => $ct
		));
		if(!$id){
			$ret['code'] = '-3';
			ex($ret);
		}
		$this->db->cache_delete('sms', 'template');

		$this->syslog->add('admin', '添加短信模板');

		$ret['id'] = $id;

		// 同步到短信平台
		if(isset($syncable) && $syncable == 1){
			$ret['sync'] = $this->service->sms_sync(str_replace('%s', '@', $ct), $tpl_name) ? 1 : 0;
		}

		ex($ret);
	}

	// 修改模板
	public function tpl_modify(){
		$ret = array('code' => 1);
		$ct  = $this->input->post('ct');
		if($ct !== $this->security->xss_clean($ct)){
			$ret['code'] = -2;
			$ret['msg'] = $this->lang->line('xss_tip');
			ex($ret);
		}

		$id = $this->input->post('id');
		$id = intval($id);
		if(!$id) exit('-1');
		
		if(!$this->service->modify_tpl_by_id($id, array('content' => $ct))){
			$ret['code'] = -1;
		}else{
			$this->db->cache_delete('sms', 'template');
			$this->syslog->add('admin', "修改短信模板，id:{$id}");
		}
		ex($ret);
	}
}