<?php
// 水卡管理
defined('BASEPATH') OR exit('No direct script access allowed');

class WaterCard extends Admin_Controller{

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->title .= ' - 水卡管理';
		$this->style_path = array(
			$this->static_path . 'css/compiled/tables.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
		);

		$data = array();
		$param = array('where' => array(), 'like' => array());

		$param['order'] = 'b.id desc';
		$param['pagesize'] = 12;

		// 搜索
		$search_param = $this->get_search_param();
		// 搜索水卡
		$wl = !empty($search_param['wl']) ? $search_param['wl'] : '';
		if($wl){
			$data['wl'] = $wl = $this->security->xss_clean($wl);
			$param['like']['b.wl'] = $wl;
		}
		// 搜索经销商
		$jxs = !empty($search_param['jxs']) ? $search_param['jxs'] : '';
		if($jxs){
			$data['jxs'] = $jxs = $this->security->xss_clean($jxs);
			$param['like']['b.to_id'] = $jxs;
			
		}

		$myjxs  = $this->service->get_my_jxs();
		$param['where_in'] = array('to_id' => $myjxs);

		$data['list'] = $this->service->get_water_card_list($param);
		// echo $this->db->last_query();exit;
		$data['pagelist'] = $this->service->get_pagelist(array(
			'table'    => 'bianma_ as b',
			'where'    => $param['where'],
			'where_in' => $param['where_in'],
			'like'     => $param['like']
		));


		$this->load->view('admin/waterCard/index.html', $data);
	}
	
	function edit($id){
		$id = intval($id);
		if(!$id) exit($this->lang->line('xss_tip'));

		$this->style_path = array(
			$this->static_path . 'css/lib/font-awesome.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
			$this->static_path . 'css/compiled/tables.css',
			$this->static_path . 'css/lib/select2.css',
			$this->static_path . 'css/lib/bootstrap-datetimepicker.min.css',
		);
		$this->script_path = array(
			$this->static_path . 'js/select2.min.js',
			$this->static_path . 'js/jquery.uniform.min.js',
			$this->static_path . 'js/bootstrap-datetimepicker.min.js',
			$this->static_path . 'js/locales/bootstrap-datetimepicker.zh-CN.js',
		);

		$data = array();
		$data['card'] = $this->service->get_card_by_id($id);
		// 套餐
		$data['item_set'] = $this->load_service('goods')->get_item_set();
		$data['jxs'] = $this->load_service('customer')->get_all_customer_map();

		$this->load->view('admin/waterCard/edit.html', $data);
	}

	function edit_update(){
		extract($_POST);
		$id = intval($id);
		$uid_type = intval($uid_type);

		$ret = array('code' => 1);
		if(!in_array($is_point, array(0, 1, 2)) ||
			!is_numeric($jxs_id) || 
			!is_numeric($real_price) || $real_price < 0 ||
			$par_time !== $this->security->xss_clean($par_time) // 这个时间 有些记录还是0000-00-00的 不能用有效时间来判断
		){
			$ret['code'] = -1;
			$ret['msg']  = $this->lang->line('xss_tip');
			ex($ret);
		}

		$card = $this->service->get_card_by_id($id);
		$afted = false;

		// 判断是否需要更新
		$need_update = 
			$card['uid_type'] != $uid_type || 
			$card['is_point'] != $is_point || 
			$card['to_id'] != $jxs_id || 
			$card['real_price'] != $real_price || 
			$card['par_time'] != $par_time;

		if(!$need_update){
			$ret['code'] = -2;
			$ret['msg']  = '未作任何修改！';
			ex($ret);
		}

		$uid_money = $card['uid_money'];
		// 变更套餐需变更初始价格字段
		if($card['uid_type'] != $uid_type){
			$uid_money = $this->load_service('goods')->get_item_by_id($uid_type, 'shop_price');
			$uid_money = $uid_money['shop_price'];
		}

		// 更新水卡表
		$this->db->update('bianma_', array(
			'uid_type'   => $uid_type,
			'is_point'   => $is_point,
			'to_id'      => $jxs_id,
			'real_price' => $real_price,
			'par_time'   => $par_time,
			'uid_money'  => $uid_money
		), array('id' => $id));

		if(!$afted && $this->db->affected_rows() > 0){
			$afted = true;
		}

		$log_msg = '编辑水卡';
		// 更新对账表
		do{
			// 未绑定的无需修改
			if(!$card['use_flag']) break;

			// 变更经销商或套餐同时修改对账表
			if($card['to_id'] != $jxs_id || $card['uid_type'] != $uid_type){
				$row = $this->load_service('finance')->get_finance_log(array('wl' => $card['wl'], 'real_money' => $card['real_price']));
				if(empty($row)) {
					// echo $this->db->last_query();
					break;
				}

				$rebate = 0;
				// 不是空卡,经销商不是天峰金辉,计算返利
				if($uid_type != 248 && $jxs_id != '111'){
					$rebate = $this->service->get_jxs_rebate($jxs_id, $uid_type);
				}

				$r = $this->db->simple_query("update {$this->db->dbprefix}cw_reconc_log set valid = 0,rebate=-rebate,real_money=-real_money,money=-money where wl='{$card['wl']}'");
				if($r){ 
					$afted = true;
					if($card['to_id'] != $jxs_id) $log_msg .= '，修改经销商';
					if($card['uid_type'] != $uid_type) $log_msg .= '，修改套餐';
				}

				$time = date('Y-m-d H:i:s');
				$this->db->insert('cw_reconc_log', array(
					'jxs'         => $jxs_id,
					'unit_price'  => $this->service->get_jxs_rebate($jxs_id),
					'real_money'  => $real_price,
					'money'       => $uid_money,
					'xtype'       => $row[0]['xtype'],
					'rebate'      => $rebate,
					'wl'          => $card['wl'],
					'create_time' => $time,
					'act_time'    => $time,
					'source'      => '编辑单个水卡',
					'orderid'     => ''
				));
				if(!$afted && $this->db->affected_rows() > 0){
					$afted = true;
				}
			}

			// 变更价格同时修改对账表
			if($card['real_price'] != $real_price){
				$this->db->update('cw_reconc_log', array(
					'real_money' => $real_price
				), array('wl' => $card['wl'], 'xtype' => 'open', 'real_money >'=> 0));

				if($this->db->affected_rows() > 0){
					$afted = true;
					$log_msg .= '，修改实际价格';
				}
			}

		}while(false);

		if(!$afted){
			$ret['code'] = -2;
			$ret['msg']  = '未作任何修改！';
		}else{
			$this->db->cache_delete('waterCard', 'index');
			$this->db->cache_delete('waterCard', 'edit');
			$this->db->cache_delete('waterCard', 'edit_update');

			$this->syslog->add_admin_card($card['wl'], $log_msg);
		}
		
		ex($ret);
	}


}