<?php 
// 管理员管理
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminUser extends Admin_Controller{

	private $serivice;

	public function __construct(){
		parent::__construct();
	}

	// 管理员列表
	public function index(){
		$this->title .= ' - 管理员管理';
		$this->style_path = array($this->static_path . 'css/compiled/tables.css');

		$data = array();
		$param = array('status' => 1, 'where' => array());

		// 搜索
		$search_param = $this->get_search_param();
		// 搜索用户名
		$uname = empty($search_param['uname']) ? '' : $search_param['uname'];
		if($uname){
			$data['uname'] = $uname = $this->security->xss_clean($uname);

			$param['where']['user_name like'] = "%{$uname}%";
		}
		// 搜索是否为经销商
		$jxs = empty($search_param['jxs']) ? '' : $search_param['jxs'];
		switch ($jxs) {
			// 经销商
			case '2':
				$param['where']['jxs_id !='] = 0;
				$data['jxs'] = 2;
			break;
			// 非经销商
			case '3':
				$param['where']['jxs_id ='] = 0;
				$data['jxs'] = 3;
			break;
			default:
				$data['jxs'] = 1;
		}

		$data['data'] = $this->service->get_user_list($param);
		// 用于点击修改角色
		$data['role'] = $this->service->get_role();

		$data['pagelist'] = $this->service->get_pagelist(array(
			'table' => 'admin_user',
			'where' => $param['where']
		));

		$this->load->view('admin/user/index.html', $data);
	}

	// 添加管理员
	public function add(){
		$uname   = $this->input->post('user_name');
		$pwd     = $this->input->post('pwd');
		$tel     = $this->input->post('mobile');
		$role_id = $this->input->post('role_id');

		$ret = array();
		if(empty($uname) || empty($pwd)) exit('-1');
		if($uname !== $this->security->xss_clean($uname)){
			$ret['code'] = -2;
			$ret['msg'] = $this->lang->line('xss_tip');
			ex($ret);
		}
		if(!empty($tel) && !preg_match('#^1[34578]\d{9}$#', $tel)) exit('-3');

		$action_list = '';
		$role_id = intval($role_id);
		if(!empty($role_id)){
			$res = $this->service->get_role('action_list', array('role_id' => $role_id));
			$action_list = $res[$role_id];
		}


		$salt = mt_rand(1000, 10000);
		$this->db->insert('admin_user', array(
			'user_name' => $uname,
			'ec_salt' => $salt,
			'password' => $this->service->get_encrypted_pwd($pwd, $salt),
			'add_time' => time(),
			'mobile' => $tel,
			'action_list' => $action_list,
			'role_id' => $role_id
		));
		if($this->db->affected_rows() > 0){
			$ret['code'] = 1;
			$this->db->cache_delete('adminUser', 'index');
			$this->db->cache_delete('adminUser', 'edit');
		}else{
			$ret['code'] = -5;
		}

		ex($ret);
	}

	// 禁用管理员
	public function disable($id){
		$id = intval($id);
		if(empty($id)) exit('-1');
		$status = $this->input->post('status');

		if(!in_array($status, array(-1, 1))) exit('-1');
		$status = $status == 1 ? -1 : 1;

		$this->db->update('admin_user', array('status' => $status), array('user_id' => $id));

		$this->db->cache_delete('adminUser', 'index');
		$this->db->cache_delete('adminUser', 'edit');

		$this->syslog->add_admin("禁用管理员,id:{$id}");
		exit('1');
	}

	// 编辑管理员
	public function edit($id){
		$id = intval($id);
		if(!$id) exit('-1');
		$user = $this->service->get_user_by_id($id);
		if(empty($user)) exit($this->lang->line('err_system'));

		// 详细页
		$this->style_path = array(
			$this->static_path . 'css/lib/font-awesome.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
			$this->static_path . 'css/compiled/tables.css'
		);

		$data = array();
		$data['user'] = $user;

		$data['priv'] = $this->service->get_all_permission();
		// roles换成两个数组
		$roles = $this->service->get_role('role_name,action_list');
		$role = $role_priv = array();
		foreach ($roles as $id => $r) {
			$role[$id] = $r['role_name'];
			$role_priv[$id] = $r['action_list'];
		}
		$data['role'] = $role;
		$data['role_priv'] = $role_priv;

		$this->load->view('admin/user/edit.html', $data);
	}

	// 编辑管理员 提交
	public function edit_update(){
		$uid       = intval($this->input->post('uid'));
		$mobile    = $this->input->post('mobile');
		$newpwd    = $this->input->post('newpwd');
		$priv      = $this->input->post('priv' ,'');
		$role_id   = intval($this->input->post('role_id'));
		$user_name = $this->input->post('user_name');

		$ret = array();
		if(!$uid) exit('-1');
		if(!empty($mobile) && !preg_match('#^1[34578]\d{9}$#', $mobile)){
			$ret['code'] = -1;
			$ret['msg']  = '手机号格式不正确';
			ex($ret);
		}
		if(!empty($newpwd) && strlen($newpwd) < 5){
			$ret['code'] = -2;
			$ret['msg']  = '密码过短';
			ex($ret);
		}
		if($user_name !== $this->security->xss_clean($user_name)) exit('-4');
		// 判断提交的权限组是否合法,如果正常那么取交集返回数量应和提交的数量一致
		$all_priv = $this->service->get_sons_permission();
		if(!empty($priv) && $priv !== 'all' && count($priv) !== count(array_intersect($all_priv, $priv))) exit('-2');
		if(!$role_id) exit('-3');

		$row = array(
			'user_name' => $user_name,
			'mobile'    => $mobile,
			'action_list' => is_array($priv) ? implode(',', $priv) : $priv,
			'role_id' => $role_id
		);
		if(!empty($newpwd)){
			$row['ec_salt'] = mt_rand(1000, 10000);
			$row['password'] = $this->service->get_encrypted_pwd($newpwd, $row['ec_salt']);
		}

		$this->db->update('admin_user', $row, array('user_id' => $uid));

		if($this->db->affected_rows() > 0){
			$ret['code'] = 1;

			$this->db->cache_delete('adminUser', 'index');
			$this->db->cache_delete('adminUser', 'edit');

			$this->syslog->add('admin', "编辑管理员,id:{$uid}");
		}else{
			$ret['code'] = -5;
			$ret['msg']  = '未作任何修改！';
		}
		ex($ret);
	}

	// 角色列表
	public function role(){
		$this->title .= ' - 角色管理';
		$this->style_path = array($this->static_path . 'css/compiled/tables.css');

		$this->load->view('admin/user/role.html', array(
			'data' => $this->service->get_role('role_name,role_describe')
		));
	}

	// 添加角色
	public function role_add(){
		// ajax提交
		if(!empty($_POST)){
			$ret = array('code' => 1);
			$data = array();
			$desc = $this->input->post('role_describe');
			$name = $this->input->post('role_name');
			$priv = $this->input->post('priv');

			if(empty($priv)){
				$ret['code'] = -6;
				$ret['msg']  = '请选择权限';
				ex($ret);
			}

			if($desc !== $this->security->xss_clean($desc) || $name !== $this->security->xss_clean($name)){
				$ret['code'] = '-1';
				$ret['msg']  = $this->lang->line('xss_tip');
				ex($ret);
			}
			$all_priv = $this->service->get_sons_permission();
			// 判断提交的权限组是否合法,如果正常那么取交集返回数量应和提交的数量一致
			if($priv !== 'all' && count($priv) !== count(array_intersect($all_priv, $priv))) exit('-2');

			if($this->db->where('role_name', $name)->count_all_results('role') > 0){
				$ret['code'] = '-5';
				$ret['msg']  = '该角色已存在';
				ex($ret);
			}

			if(is_array($priv)) $priv = implode(',', $priv);
			$data['action_list'] = $priv;
			$data['role_describe'] = $desc;
			$data['role_name'] = $name;

			$this->db->insert('role', $data);
			if($this->db->affected_rows() > 0){
				$ret['code'] = 1;
				$this->db->cache_delete('adminUser', 'role');
				$this->db->cache_delete('adminUser', 'role_edit');
			}else{
				$ret['code'] = -3;
			}

			ex($ret);
		}

		// 详细页
		$this->style_path = array(
			$this->static_path . 'css/lib/font-awesome.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
			$this->static_path . 'css/compiled/tables.css'
		);

		$data = array();
		$data['priv'] = $this->service->get_all_permission();

		$this->load->view('admin/user/role_add.html', $data);
	}

	// 编辑角色
	public function role_edit($id){
		$role_id = intval($id);
		if(!$role_id) exit('-1');

		// ajax提交
		if(!empty($_POST)){
			$ret = array();
			$data = array();
			$data['role_name'] = $this->input->post('role_name');
			$data['role_describe'] = $this->input->post('role_describe');
			$priv = $this->input->post('priv');

			if($data['role_name'] !== $this->security->xss_clean($data['role_name']) || $data['role_describe'] !== $this->security->xss_clean($data['role_describe'])){
				$ret['code'] = -3;
				$ret['msg']  = $this->lang->line('xss_tip');
				ex($ret);
			}
			if(!is_array($priv) && $priv !== 'all') exit('-1');
			// 判断提交的权限组是否合法,如果正常那么取交集返回数量应和提交的数量一致
			$all_priv = $this->service->get_sons_permission();
			if($priv !== 'all' && count($priv) !== count(array_intersect($all_priv, $priv))) exit('-2');
			if(is_array($priv)) $priv = implode(',', $priv);
			$data['action_list'] = $priv;

			$this->db->update('role', $data, array('role_id' => $id));
			if($this->db->affected_rows() > 0){
				$ret['code'] = 1;
				$this->db->cache_delete('adminUser', 'role');
				$this->db->cache_delete('adminUser', 'role_edit');

				$this->syslog->add('admin', "编辑角色,role_id:{$id}");
			}else{
				$ret['code'] = -4;
			}
			ex($ret);
		}

		// 详细页
		$this->style_path = array(
			$this->static_path . 'css/lib/font-awesome.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
			$this->static_path . 'css/compiled/tables.css'
		);

		$data = array();

		$role = $this->service->get_role('role_name,action_list,role_describe', array('role_id' => $role_id));
		if(empty($role[$role_id])) exit('系统错误，请联系管理员');
		$role = $role[$role_id];

		$data['priv'] = $this->service->get_all_permission();
		$data['role'] = $role;


		$this->load->view('admin/user/role_edit.html', $data);
	}

	// 权限管理
	public function priv(){
		// 添加权限
		if(!empty($_POST)){
			$ret = array('code' => 1);
			$priv_name = $this->input->post('priv_name');
			$action_code = $this->input->post('action_code');
			$parent_id = intval($this->input->post('parent_id'));

			if($priv_name !== $this->security->xss_clean($priv_name) || $action_code !== $this->security->xss_clean($action_code)){
				$ret['code'] = -1;
				$ret['msg']  = $this->lang->line('xss_tip');
				ex($ret);
			}
			if($parent_id < 0 || $parent_id > 1000) ex('-2');

			// priv_name写入语言文件,没写入权限也行,权限就显示英文名了
			$file = APPPATH . 'language/' . $this->config->item('language') . '/permission_lang.php';
			$ct = "\r\n\$lang['{$action_code}'] = '$priv_name';";
			@file_put_contents($file, $ct, FILE_APPEND);

			$this->db->insert('admin_action', array(
				'action_code' => $action_code,
				'parent_id'   => $parent_id
			));

			$this->db->cache_delete('adminUser', 'priv');
			$this->db->cache_delete('adminUser', 'role_add');
			$this->db->cache_delete('adminUser', 'role_edit');
			$this->db->cache_delete('adminUser', 'edit_update');

			ex($ret);
		}

		$this->title .= ' - 权限管理';
		$this->style_path = array(
			$this->static_path . 'css/compiled/tables.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
		);


		$data = array();
		$data['priv'] = $this->service->get_all_permission();
		$data['parent_priv'] = $this->service->get_parent_permission();

		$pagesize = 20;
		$count = 0;
		foreach ($data['priv'] as $id=>$d) {
			++$count;
			if(!empty($d['sons']))
				$count += count($d['sons']);
		}
		// 分页
		$this->load->library('page', array(
			'total'     => $count,
			'maxpageno' => 100,
			'pagesize'  => $pagesize,
			'url'       => '#'
		));
		$data['pagelist'] = $this->page->pagelist(1);
		$data['total']    = $count;
		$data['pagesize'] = $pagesize;

		// dump($priv);exit;

		$this->load->view('admin/user/priv.html', $data);
	}

	public function priv_del($id){
		$id = intval($id);
		if(!$id) exit('-1');

		// todo..
		// 同时删除语言文件permission_lang.php中相应内容
		// 不删问题也不大

		$ret = array('code' => 1);
		$delete_row = $this->db->select('action_id,parent_id')->from('admin_action')->get()->row();
		// 删除所有子权限
		if($delete_row->parent_id === '0'){
			$this->db->delete('admin_action', array('parent_id' => $id));
		}
		$this->db->delete('admin_action', array('action_id' => $id));

		if($this->db->affected_rows() > 0){
			$ret['code'] = 1;

			$this->db->cache_delete('adminUser', 'priv');
			$this->db->cache_delete('adminUser', 'role_add');
			$this->db->cache_delete('adminUser', 'role_edit');
			$this->db->cache_delete('adminUser', 'edit_update');
		}
		ex($ret);
	}

	/**
	 * 根据uid修改admin_user表数据
	 * @return array 
	 */
	public function modify_user(){
		$ret = array();
		$uid = $this->input->post('uid');
		$data = $this->input->post('data');
		$uid = intval($uid);
		if($uid < 0 || empty($data)) exit('-1');

		// 允许修改的字段
		$allow_modified = array('role_id', 'mobile');
		$post_keys = array_keys($data);
		// 取交集数量不等说明有不允许字段提交
		if(count($post_keys) !== count(array_intersect($allow_modified, $post_keys))) exit('-2');

		// 防注入
		foreach ($data as $d) {
			if($d !== $this->security->xss_clean($d)){
				$ret['code'] = '-3';
				$ret['msg']  = '系统错误，请联系管理员(code:-3)';
				ex($ret);
			}
		}

		// 如果是更新角色 则同时更新action_list字段
		if(in_array('role_id', $post_keys)){
			$roles = $this->service->get_role('action_list');
			if(!isset($roles[$data['role_id']])) exit('-5');
			$data['action_list'] = $roles[$data['role_id']];
		}

		$this->db->update('admin_user', $data, array('user_id' => $uid));
		if($this->db->affected_rows() > 0){
			$ret['code'] = 1;
			$this->db->cache_delete('adminUser', 'index');
			$this->db->cache_delete('adminUser', 'edit');

			$this->syslog->add('admin', "修改管理员,user_id:{$uid}");
		}else{
			$ret['code'] = -4;
		}
		
		ex($ret);
	}
}