<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends Admin_Controller{

	// 记住我
	private $remember_day = 30;

	public function index(){
		$this->title .= ' - 登陆';
		$this->style_path = array($this->static_path . 'css/compiled/signin.css');

		$this->load->language('login');

		$this->db->cache_off();

		// ajax登陆
		if(!empty($_POST)){
			$uname = $this->input->post('uname');
			$pwd   = $this->input->post('pwd');
			$rem   = $this->input->post('rem');

			$res = $this->service->check_login($uname, $pwd);
			if($res['code'] != 1) ex($res);

			$user = $res['user'];
			// 登陆成功需更新数据
			$update_info = array();
			
			if(empty($user['ec_salt'])){
				$update_info['ec_salt']  = mt_rand(1000, 10000);
				$update_info['password'] = $this->service->get_encrypted_pwd($pwd, $update_info['ec_salt']);
			}

			// 记住我
			if($rem == 1){
				$cfg = get_config();
				setcookie(session_name(), session_id(), time() + $this->remember_day * 86400, $cfg['cookie_path'], $cfg['cookie_domain'], $cfg['cookie_secure'], true);
			}

			$action = $user['action_list'];
			if($action != 'all'){
				$action = explode(',', $action);
        		$action = array_map('strtolower', $action);
			}

			$this->session->set_userdata(array(
				'uid'         => $user['user_id'],
				'user_name'   => $user['user_name'],
				'action_list' => $action,
				'isjxs'       => !empty($user['jxs_id']) ? 1 : 0,
				'last_login'  => $user['last_login'],
				'last_ip'     => $user['last_ip']
			));

			$update_info['last_login'] = time();
			$update_info['last_ip']    = $_SERVER['REMOTE_ADDR'];
			
			$this->service->update_user_info($user['user_id'], $update_info);

			ex(array(
				'code' => 1,
				'url'  => siteurl('info')
			));
		}
		
		// 已登陆
		$uid = $this->session->userdata('uid');
		if($uid){
			$this->service->update_user_info($uid, array(
				'last_login' => time(),
				'last_ip'    => $_SERVER['REMOTE_ADDR']
			));
			redirect(siteurl('info'));
		}

		// 登陆页面
		$this->load->view('admin/login.html');
	}

	public function out(){
		session_unset();
		session_destroy();
		redirect(siteurl('login'));
	}
}