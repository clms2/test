<?php 
// 会员管理
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends Admin_Controller{

	public function __construct(){
		parent::__construct();
	}

	// 会员列表
	public function index(){
		$this->title .= ' - 管理员管理';
		$this->style_path = array(
			$this->static_path . 'css/compiled/tables.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
		);

		$data = array();
		$param = array('where' => array());

		$param['order'] = 'user_id desc';

		// 搜索
		$search_param = $this->get_search_param();
		// 搜索用户名
		$uname = !empty($search_param['uname']) ? $search_param['uname'] : '';
		if($uname){
			$data['uname'] = $uname = $this->security->xss_clean($uname);

			$param['where']['user_name like'] = "%{$uname}%";
		}

		$data['list'] = $this->service->get_member_list($param);
		$data['pagelist'] = $this->service->get_pagelist(array(
			'table' => 'users',
			'where' => $param['where']
		));

		// 省市联动
		$data['regions'] = $this->service->get_regions();

		$this->load->view('admin/member/index.html', $data);
	}

	// 会员编辑
	public function edit($id){
		$id = intval($id);
		if(!$id) exit('-1');

		// 详细页
		$this->style_path = array(
			$this->static_path . 'css/lib/font-awesome.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
			$this->static_path . 'css/compiled/tables.css'
		);

		$data = array();
		$data['user'] = $this->service->get_user_by_id($id);
		$data['regions'] = $this->service->get_regions();

		$this->load->view('admin/member/edit.html', $data);
	}

	// 编辑会员提交
	public function edit_update(){
		extract($_POST);
		$uid = intval($uid);
		$num = floatval($num);
		if(empty($province)) $province = 0;
		if(empty($city)) $city = 0;
		if(empty($area)) $area = 0;

		$ret = array('code' => 1);
		if( empty($user_name) || 
			!preg_match('#^1[34578]\d{9}$#', $user_name) || 
			(!empty($mobile) && !preg_match('#^1[34578]\d{9}$#', $mobile)) || 
			!is_numeric($province) || !is_numeric($city) || !is_numeric($area) || 
			(!empty($num) && empty($remark))
		) exit('-1');
		if( $consignee !== $this->security->xss_clean($consignee) || 
			$address !== $this->security->xss_clean($address) || 
			(!empty($remark) && $remark !== $this->security->xss_clean($remark))
		){
			$ret['code'] = -2;
			$ret['msg']  = $this->lang->line('xss_tip');
			ex($ret);
		}

		$user = $this->service->get_user_by_id($uid);
		$afted = false;

		$log_msg = '编辑会员,id:' . $uid;
		// 更新积分变更表 account_log
		if(!empty($num)){
			$this->load_service('account')->add_account_log(array(
				'user_id'     => $user['user_id'],
				'pay_points'  => $num,
				'change_time' => time(),
				'change_desc' => $remark,
				'change_type' => 4,
				'admin_id'    => $this->session->userdata('uid')
			));
			if($this->db->affected_rows() > 0){
				$afted = true;
				$log_msg .= '，修改积分';
			}
			$this->db->update('users', array('pay_points' => $num + $user['pay_points']), array('user_id' => $user['user_id']));
		}

		// 更新users表
		// 判断是否需要更新其他信息
		if(!empty($newpwd) || $user_name != $user['user_name'] || $gender != $user['sex']){
			// 如果更改手机号 先判断是否已存在
			if($user_name != $user['user_name']){
				if($this->service->get_total('users', array('where' => array('user_name' => $user_name))) > 0){
					$ret['code'] = -3;
					$ret['msg']  = '会员登录名已存在！';
					ex($ret);
				}
			}
			$data = array(
				'user_name' => $user_name,
				'sex'       => $gender
			);
			if(!empty($newpwd)){
				$data['ec_salt']  = mt_rand(1000, 10000);
				$data['password'] = $this->service->get_encrypted_pwd($newpwd, $data['ec_salt']);
			}
			$this->db->update('users', $data, array('user_id' => $uid));
			if(!$afted && $this->db->affected_rows() > 0){
				$afted = true;
			}
		}
		
		// 更新默认收货地址
		if($province != $user['province'] || 
			$city != $user['city'] || 
			$area != $user['district'] || 
			$address != $user['address'] || 
			$consignee != $user['consignee'] || 
			$mobile != $user['mobile']
		){
			$this->db->update('user_address', array(
				'address'   => $address,
				'consignee' => $consignee,
				'province'  => $province,
				'city'      => $city,
				'district'  => $area,
				'mobile'    => $mobile
			), array('address_id' => $user['address_id']));
			if(!$afted && $this->db->affected_rows() > 0){
				$afted = true;
			}
		}

		if(!$afted){
			$ret['code'] = -5;
			$ret['msg']  = '未作任何修改！';
		}else{
			$this->db->cache_delete('member', 'index');
		}

		ex($ret);
	}

	// 禁用会员
	public function disable($id){
		$id = intval($id);
		if(empty($id)) exit('-1');
		$status = $this->input->post('status');

		if(!in_array($status, array(-1, 1))) exit('-1');
		$status = $status == 1 ? -1 : 1;

		$this->db->update('users', array('status' => $status), array('user_id' => $id));
		$this->db->cache_delete('member', 'index');
		$this->db->cache_delete('member', 'edit');
		exit('1');
	}

	// 标记退款记录为已删除
	public function refund_del($id){
		$id = intval($id);
		if(empty($id)) exit('-1');

		$this->db->update('user_account', array('deleted' => 1), array('id' => $id));
		exit('1');
	}

	// 添加会员
	public function add(){
		extract($_POST);
		if(empty($province)) $province = 0;
		if(empty($city)) $city = 0;
		if(empty($area)) $area = 0;
		if(empty($addr)) $addr = '';
		if(empty($consignee)) $consignee = '';

		$ret = array();
		if(empty($uname) || empty($pwd)) exit('-1');
		if(!preg_match('#^1[34578]\d{9}$#', $uname) || !in_array($gender, array(1,2))) exit('-2');
		if($uname !== $this->security->xss_clean($uname) || $addr !== $this->security->xss_clean($addr)){
			$ret['code'] = -4;
			$ret['msg']  = $this->lang->line('xss_tip');
			ex($ret);
		}
		$exists = $this->service->get_total('users', array('where' => array('user_name' => $uname))) > 0;
		if($exists){
			$ret['code'] = -3;
			$ret['msg']  = '该手机号已存在！';
			ex($ret);
		}

		// todo.. 
		// 改成事务
		$salt = mt_rand(1000, 10000);
		$this->db->insert('users', array(
			'ec_salt'   => $salt,
			'user_name' => $uname,
			'password'  => $this->service->get_encrypted_pwd($pwd, $salt);,
			'sex'       => $gender,
			'source'    => '400',
			'reg_time'  => time(),
			'jxsid'     => '111'
		));
		if($this->db->affected_rows() != 1){
			$ret['code'] = -5;
			$ret['msg']  = $this->lang->line('err_system');
			ex($ret);
		}
		$uid = $this->db->insert_id();

		// 有填收货信息
		if(!empty($province) || !empty($addr)){
			if(!is_numeric($province) || !is_numeric($city) || !is_numeric($area)) exit('-22');
			$this->db->insert('user_address', array(
				'user_id'   => $uid,
				'consignee' => $consignee,
				'country'   => 1,
				'province'  => $province,
				'city'      => $city,
				'district'  => $area,
				'address'   => $addr,
				'mobile'    => $uname
			));
			if($this->db->affected_rows() != 1){
				$ret['code'] = -6;
				$ret['msg']  = $this->lang->line('err_system');
				ex($ret);
			}
			$addr_id = $this->db->insert_id();
			$this->db->update('users', array('address_id' => $addr_id), array('user_id' => $uid));
		}

		$this->db->cache_delete('member', 'index');

		$ret['code'] = 1;
		ex($ret);
	}

	// 充值和提现申请 要用到的话需修改分页为调用service
	public function refund(){
		$this->title .= ' - 充值和提现申请';
		$this->style_path = array(
			$this->static_path . 'css/compiled/tables.css',
			$this->static_path . 'css/compiled/form-showcase.css',
			$this->static_path . 'css/lib/uniform.default.css',
		);

		$data = array();
		$where = array();
		$url = '';

		$page = intval($this->input->get('page'));
		$page = $page <= 0 ? 1 : $page;
		$pagesize = 15;
		$offset = ($page-1) * $pagesize;

		$param['pagesize'] = $pagesize;
		$param['offset'] = $offset;

		$param['deleted'] = 0;
		$where['deleted'] = 0;

		// 搜索
		$uname = $this->input->get('uname');
		if($uname){
			$data['uname'] = $uname = $this->security->xss_clean($uname);

			$param['user_name like'] = $where['user_name like'] = "%{$uname}%";

			$url .= "uname={$uname}&";
		}

		$data['list'] = $this->service->get_refund_list($param);

		$data['payment'] = $this->service->get_payment();

		// 分页
		$this->load->library('page', array(
			'total'     => $this->service->get_total('user_account', array('where' => $where)),
			'pagesize'  => $pagesize,
			'url'       => siteurl('member') . "/refund?{$url}page="
		));
		$data['pagelist'] = $this->page->pagelist($page);


		$this->load->view('admin/member/refund.html', $data);
	}


}