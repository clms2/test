<?php

//共用函数文件

//打印调试
function dump(){
	$args = func_get_args();

	echo "<pre>";
	foreach ($args as $a) {
		if(is_array($a)){
			print_r($a);
		}else{
			var_dump($a);
		}
	}
	echo "</pre>";
	exit;
}

function ex($arr){
	exit(json_encode($arr));
}

//curl模拟请求
function curl_send($url, $data = null, $options = null){
	$ch = curl_init($url);
	if(isset($data)){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($data) ? http_build_query($data) : $data);
	}
	if(isset($options)){
		curl_setopt_array($ch, $options);
	}
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$result = curl_exec($ch);
	if(curl_errno($ch)){
		$result = curl_error($ch);
	}
	curl_close($ch);
	return $result;
}

//重写路由函数
function siteurl($route){
	$cfg = get_config();
	$prefix = $cfg['admin_path'];
	
	if($_SERVER['HTTP_HOST'] != 'mall.zhuomaspring.com'){
		return str_replace('/index.php','',site_url($prefix . '/' . $route));
	}else{
		return str_replace_limit('/index.php','',site_url($prefix . '/' . $route),1);
	}
}

/**
 * 查找替换方法
 */
function str_replace_limit($search, $replace, $subject, $limit=-1){  
	if(is_array($search)){  
		foreach($search as $k){  
			$search[$k] = '`'. preg_quote($search[$k], '`'). '`';  
		}  
	}else{  
		$search = '`'. preg_quote($search, '`'). '`';  
	}  
	return preg_replace($search, $replace, $subject, $limit);  
}

/**
 * array_key_exists的递归搜索
 * @param  string $key   键名
 * @param  array $arr   
 * @param  string $field 如果找到键那么返回该数组的指定字段
 * @return string/boolean  
 */
function array_key_exists_deep($key, $arr, $field = null){
	if(array_key_exists($key, $arr)){
		if(isset($field)){
			return $arr[$key][$field];
		}
		return true;
	}
	foreach ($arr as $a) {
		if(is_array($a)){
			$r = array_key_exists_deep($key, $a, $field);
			if($r){
				return $r;
			}
		}
	}

	return false;
}



/**
 * 得到新订单号
 * @return  string
 */
function get_order_sn()
{
	return date('ymd').substr(time(),-5).substr(microtime(),2,3).'58';
}


/**
 * 隐藏手机号的中间四位
 */
 function get_encrypt_name($name){
	 return substr($name, 0, 3)."****" . substr($name,-4);
 }
 
 /**
  * 将字符串按指定字符划分
  */
 function format_num($str,$num,$char=' '){
	 $length = strlen($str);
	 $new_str = '';
	 for($i=0;$i<$length;$i++){
		 $new_str .= $str[$i];
		 if(($i+1)%$num==0){
			 $new_str .= $char;
		 }
	 }
	 return $new_str;
 }
 
 
 
 /**
  *  将一个字串中含有全角的数字字符、字母、空格或'%+-()'字符转换为相应半角字符
  *
  * @access  public
  * @param   string	   $str		 待转换字串
  *
  * @return  string	   $str		 处理后字串
  */
 function make_semiangle($str)
 {
 	$arr = array('０' => '0', '１' => '1', '２' => '2', '３' => '3', '４' => '4',
 			'５' => '5', '６' => '6', '７' => '7', '８' => '8', '９' => '9',
 			'Ａ' => 'A', 'Ｂ' => 'B', 'Ｃ' => 'C', 'Ｄ' => 'D', 'Ｅ' => 'E',
 			'Ｆ' => 'F', 'Ｇ' => 'G', 'Ｈ' => 'H', 'Ｉ' => 'I', 'Ｊ' => 'J',
 			'Ｋ' => 'K', 'Ｌ' => 'L', 'Ｍ' => 'M', 'Ｎ' => 'N', 'Ｏ' => 'O',
 			'Ｐ' => 'P', 'Ｑ' => 'Q', 'Ｒ' => 'R', 'Ｓ' => 'S', 'Ｔ' => 'T',
 			'Ｕ' => 'U', 'Ｖ' => 'V', 'Ｗ' => 'W', 'Ｘ' => 'X', 'Ｙ' => 'Y',
 			'Ｚ' => 'Z', 'ａ' => 'a', 'ｂ' => 'b', 'ｃ' => 'c', 'ｄ' => 'd',
 			'ｅ' => 'e', 'ｆ' => 'f', 'ｇ' => 'g', 'ｈ' => 'h', 'ｉ' => 'i',
 			'ｊ' => 'j', 'ｋ' => 'k', 'ｌ' => 'l', 'ｍ' => 'm', 'ｎ' => 'n',
 			'ｏ' => 'o', 'ｐ' => 'p', 'ｑ' => 'q', 'ｒ' => 'r', 'ｓ' => 's',
 			'ｔ' => 't', 'ｕ' => 'u', 'ｖ' => 'v', 'ｗ' => 'w', 'ｘ' => 'x',
 			'ｙ' => 'y', 'ｚ' => 'z',
 			'（' => '(', '）' => ')', '〔' => '[', '〕' => ']', '【' => '[',
 			'】' => ']', '〖' => '[', '〗' => ']', '“' => '[', '”' => ']',
 			'‘' => '[', '’' => ']', '｛' => '{', '｝' => '}', '《' => '<',
 			'》' => '>',
 			'％' => '%', '＋' => '+', '—' => '-', '－' => '-', '～' => '-',
 			'：' => ':', '。' => '.', '、' => ',', '，' => '.', '、' => '.',
 			'；' => ',', '？' => '?', '！' => '!', '…' => '-', '‖' => '|',
 			'”' => '"', '’' => '`', '‘' => '`', '｜' => '|', '〃' => '"',
 			'　' => ' ');
 
 	return strtr($str, $arr);
 }
 
 /**
  *  随机生成一个订单号
  *
  * @access  public
  * @param   string	  $type		类型
  *
  * @return  boolen	  $result
  */
 function order_sn_type($type){
	 $order_sn =  $type.date('ymd').substr(time(),-5).substr(microtime(),2,2).'68'; //订单号
	 return $order_sn;
 }
 
 /**
  * 写日志方法
  */
 function log_write($arg, $file = '')
{
	$str = "\r\n-- ". date('Y-m-d H:i:s'). " --------------------------------------------------------------\r\n";
	$str .= "FILE: $file\r\n";

	if (is_array($arg))
	{
		$str .= '$arg = array(';
		foreach ($arg AS $val)
		{
			foreach ($val AS $key => $list)
			{
				$str .= "'$key' => '$list'\r\n";
			}
		}
		$str .= ")\r\n";
	}
	else
	{
		$str .= $arg;
	}

	file_put_contents(dirname(__FILE__) . '/logs/log.txt', $str);
}

/**
 * 加密函数
 * @param   string  $str	加密前的字符串
 * @param   string  $key	密钥
 * @return  string  加密后的字符串
 */
function encrypt($str, $key = AUTH_KEY)
{
	$coded = '';
	$keylength = strlen($key);

	for ($i = 0, $count = strlen($str); $i < $count; $i += $keylength)
	{
		$coded .= substr($str, $i, $keylength) ^ $key;
	}

	return str_replace('=', '', base64_encode($coded));
}

/**
 * 解密函数
 * @param   string  $str	加密后的字符串
 * @param   string  $key	密钥
 * @return  string  加密前的字符串
 */
function decrypt($str, $key = AUTH_KEY)
{
	$coded = '';
	$keylength = strlen($key);
	$str = base64_decode($str);

	for ($i = 0, $count = strlen($str); $i < $count; $i += $keylength)
	{
		$coded .= substr($str, $i, $keylength) ^ $key;
	}

	return $coded;
}

