<?php 
class Finance_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		$this->ci->load->model('admin/Finance_model', 'finance');
	}

	function get_finance_log($where, $field = 'xtype'){
		
		return $this->ci->finance->get_finance_log($where, $field);
	}
}
