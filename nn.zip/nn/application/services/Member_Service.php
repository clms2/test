<?php 
class Member_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		$this->ci->load->model('admin/Member_model', 'member');
	}

	function get_member_list($param){
		// 从url中获取页码
		$search_param = $this->ci->get_search_param();
		$page = empty($search_param['page']) ? 1 : intval($search_param['page']);
		
		$page = $page < 1 ? 1 : $page;
		$param['pagesize'] = empty($param['pagesize']) ? 15 : intval($param['pagesize']);
		$param['offset'] = empty($param['offset']) ? ($page - 1) * $param['pagesize'] : intval($param['offset']);

		unset($param['page']);

		return $this->ci->member->get_member_list($param);
	}

	function get_refund_list($param = array()){

		return $this->ci->member->get_refund_list($param);
	}

	function get_user_by_id($id){

		return $this->ci->member->get_user_by_id($id);
	}

}