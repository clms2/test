<?php 
class WaterCard_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		$this->ci->load->model('admin/WaterCard_model', 'card');
	}

	function get_water_card_list($param){
		// 从url中获取页码
		$search_param = $this->ci->get_search_param();
		$page = empty($search_param['page']) ? 1 : intval($search_param['page']);
		
		$page = $page < 1 ? 1 : $page;
		$param['pagesize'] = empty($param['pagesize']) ? 15 : intval($param['pagesize']);
		$param['offset'] = empty($param['offset']) ? ($page - 1) * $param['pagesize'] : intval($param['offset']);

		return $this->ci->card->get_water_card_list($param);
	}

	function get_card_by_id($id){

		return $this->ci->card->get_card_by_id($id);
	}
}