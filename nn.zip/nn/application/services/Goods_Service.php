<?php 
class Goods_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		$this->ci->load->model('admin/Goods_model', 'goods');
	}

	// 获取所有套餐
	function get_item_set(){
		$data = $this->ci->goods->get_item_set();
		$ret = array();

		// 非天峰金辉下的经销商只看到活动用的套餐
		$other_jxs = $this->ci->session->userdata('isjxs') && substr($this->ci->session->userdata('user_name'), 0, 3) != '111';

		foreach ($data as $k => $d) {
			if($other_jxs){
				if(strpos($d['goods_simple_name'], '水卡套餐') !== false || strpos($d['goods_simple_name'], '促销专用水卡') !== false){
					$ret[$d['goods_id']] = $d['goods_simple_name'];
				}
			}else{
				$ret[$d['goods_id']] = $d['goods_simple_name'];
			}

		}

		return $ret;
	}

	// 获取所有套餐对应的桶装水/其他数量
	function get_item_set_num($where = array()){
		$item_set = $this->ci->goods->get_item_set_num($where);
		$ret = array();
		foreach ($item_set as $item) {
			$ct = $item['content'];
			$ct = unserialize($ct);
			if(empty($ct[0])) continue;
			$ct = $ct[0];
			$ret[$item['goods_id']] = array('num' => $ct['num'], 'tit' => $ct['name']);
		}

		return $ret;
	}

	function get_item_by_id($id, $field = 'cat_id,goods_sn,goods_name,goods_simple_name,markey_price,shop_price'){

		return $this->ci->goods->get_item_by_id($id, $field);
	}

}
