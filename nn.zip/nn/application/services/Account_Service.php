<?php 
class Account_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		$this->ci->load->model('admin/Account_model', 'account');
	}

	function add_account_log($data){

		return $this->ci->account->add_account_log($data);
	}

}
