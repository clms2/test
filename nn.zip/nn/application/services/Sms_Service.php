<?php 
class Sms_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		$this->ci->load->model('admin/Sms_model', 'sms');
	}

	function get_sms_list($param){
		// 从url中获取页码
		$search_param = $this->ci->get_search_param();
		$page = empty($search_param['page']) ? 1 : intval($search_param['page']);
		
		$page = $page < 1 ? 1 : $page;
		$param['pagesize'] = empty($param['pagesize']) ? 15 : intval($param['pagesize']);
		$param['offset'] = empty($param['offset']) ? ($page - 1) * $param['pagesize'] : intval($param['offset']);

		unset($param['page']);

		return $this->ci->sms->get_sms_list($param);
	}

	function send($tel, $msg, $sendtime = ''){

		return $this->ci->sms->send($tel, $msg, $sendtime);
	}

	function get_tpl_data($param = array()){

		return $this->ci->sms->get_tpl_data($param);
	}

	function add_tpl($data){

		return $this->ci->sms->add_tpl($data);
	}

	function sms_sync($msg, $remark = ''){

		return $this->ci->sms->sms_sync($msg, $remark);
	}

	function modify_tpl_by_id($id, $data = array()){

		return $this->ci->sms->modify_tpl_by_id($id, $data);		
	}

	function sms_remain_num(){

		return $this->ci->sms->sms_remain_num();	
	}
}