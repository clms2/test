<?php 
class Common_Service{
	private static $instance = array();
	protected $ci;

	public function __construct(){
		$this->ci = & get_instance();
		$this->ci->load->model('common_model', 'common');
	}

	public static function get_instance(){
		$class = get_called_class();
		if(isset(self::$instance[$class]))
			return self::$instance[$class];

		return self::$instance[$class] = new $class();
	}



	/**
	 * 分页
	 * @param  array $param 必要参数：array('table' => 'xxx')
	 * @return string
	 */
	function get_pagelist($param){
		$search_param = $this->ci->get_search_param();

		$page         = empty($search_param['page']) ? 1 : intval($search_param['page']);
		$page         = $page <= 0 ? 1 : $page;
		$pagesize     = empty($param['pagesize']) ? 15 : intval($param['pagesize']);
		$table        = empty($param['table']) ? 'users' : $param['table'];
		$where        = empty($param['where']) ? array() : $param['where'];
		$where_in     = empty($param['where_in']) ? array() : $param['where_in'];
		$like         = empty($param['like']) ? array() : $param['like'];

		$condition = array(
			'where'    => $where, 
			'where_in' => $where_in, 
			'like'     => $like
		);
		// 默认使用当前连接作为构造分页的url
		if(empty($param['url'])){
			// 当前控制器/方法
			$temp_url = $this->ci->get_acm();
			$temp_url = siteurl($temp_url);
			// 带上搜索参数
			// 页码不参与构造分页url
			unset($search_param['page']);
			$temp_query_str = http_build_query($search_param);
			if(!empty($temp_query_str)) $temp_query_str .= '&';
			$temp_url = $temp_url . '?' . $temp_query_str . 'page=';

			$param['url'] = $temp_url;
		}

		$this->ci->load->library('page', array(
			'total'     => $this->get_total($table, $condition),
			'pagesize'  => $pagesize,
			'url'       => $param['url']
		));

		return $this->ci->page->pagelist($page);
	}

	/**
	 * 获取表记录数
	 * @param  striing $table     表名
	 * @param  array  $condition array('where' => array(), 'where_in'=>,'like' =>)
	 * @return int    
	 */
	function get_total($table, $condition = array()){
		$db = $this->ci->db;

		if(!empty($condition['where'])){
			$db->where($condition['where']);
		}

		if(!empty($condition['where_in'])){
			foreach ($condition['where_in'] as $field => $value) {
				if(!empty($value))
					$db->where_in($field, $value);
			}
		}

		if(!empty($condition['like'])){
			$db->like($condition['like']);
		}

		return $db->count_all_results($table);
	}

	function get_regions(){

		return $this->ci->common->get_regions();
	}

	function get_payment(){
		
		return $this->ci->common->get_payment();
	}

	/**
	 * 根据明文获取密码
	 * @param  string $input 明文密码
	 * @param  string $salt  随机数
	 * @return string 
	 */
	public function get_encrypted_pwd($input, $salt = ''){

		return empty($salt) ? md5($input) : md5(md5($input) . $salt);
	}

	/**
	 * 获取当前登录用户与他之下的所有分销商，如果他是经销商的话
	 * @return array array(1,2,jxsid,..);
	 */
	function get_my_jxs(){
		// 权限为all的超级管理员，当前登录用户不是经销商的return
		if($this->ci->session->userdata('action_list') == 'all' || !$this->ci->session->userdata('isjxs')) 
			return array();

		$jxsid = $this->session->userdata('user_name');// jxs_id和user_name一致

		$this->ci->load->model('admin/Customer_model', 'customer');
		$jxs_map = $this->ci->customer->get_all_customer_map();

		$myjxs   = isset($jxs_map[$jxsid]['child']) ? $jxs_map[$jxsid]['child'] : array();
		$myjxs   = array_keys($myjxs);
		$myjxs[] = $jxsid;

		return $myjxs;
	}

	/**
	 * 获取经销商返利/指定套餐的返利
	 * 只有主品有返利 de=1
	 * @param  string $jxs_id   经销商id
	 * @param  int    $goods_id 套餐id
	 * @return float
	 */
	function get_jxs_rebate($jxs_id, $goods_id = null){
		$this->ci->load->model('admin/Customer_model', 'customer');
		$rebate = $this->ci->customer->get_jxs_by_id($jxs_id, 'rebate');
		$rebate = floatval($rebate['rebate']);

		if(!isset($goods_id)) return $rebate;

		$this->ci->load->model('admin/Goods_model', 'goods');
		// 所有套餐
		$all_item_set = $this->ci->goods->get_item_set_num(array('de' => 1));
		if(empty($all_item_set[$goods_id])) return 0;
		
		$num = $all_item_set[$goods_id];
		$num = unserialize($num['content']);
		if(empty($num[0]['num'])) return 0;
		$num = intval($num[0]['num']);

		return $rebate * $num;
	}

}