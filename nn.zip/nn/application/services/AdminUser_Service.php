<?php 
class AdminUser_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		$this->ci->load->model('admin/AdminUser_model', 'user');
	}

	function get_user_list($param){
		// 从url中获取页码
		$search_param = $this->ci->get_search_param();
		$page = empty($search_param['page']) ? 1 : intval($search_param['page']);
		
		$page = $page < 1 ? 1 : $page;
		$param['pagesize'] = empty($param['pagesize']) ? 15 : intval($param['pagesize']);
		$param['offset'] = empty($param['offset']) ? ($page - 1) * $param['pagesize'] : intval($param['offset']);

		unset($param['page']);

		return $this->ci->user->get_user_list($param);
	}

	public function get_user_by_name($name, $field = '*'){

		return $this->ci->user->get_user_by_name($name, $field);
	}

	public function update_user_info($uid, $data){

		return $this->ci->user->update_user_info($uid, $data);
	}

	function get_role($field = 'role_name', $where = array()){

		return $this->ci->user->get_role($field, $where);
	}

	function get_user_by_id($id, $fields = 'user_id,user_name,mobile,add_time,action_list,role_id'){

		return $this->ci->user->get_user_by_id($id, $fields);
	}

	function get_all_permission(){

		return $this->ci->user->get_all_permission();
	}

	function get_sons_permission($isparent = false){

		return $this->ci->user->get_sons_permission($isparent);
	}

	function get_parent_permission(){

		return $this->get_sons_permission(true);
	}
}