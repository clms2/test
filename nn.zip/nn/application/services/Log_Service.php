<?php 
class Log_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		// 别名不能用log.
		$this->ci->load->model('admin/Log_model', 'log_model');
	}

	function add($type, $param){
		switch ($type) {
			case 'admin':
				return $this->add_admin(is_array($param) && isset($param['msg']) ? $param['msg'] : $param);
			break;
			case 'admin_card':
				$wl  = isset($param['wl']) ? $param['wl'] : '';
				$msg = isset($param['msg']) ? $param['msg'] : '';

				return $this->add_admin_card($wl, $msg);
			break;
			
		}
	}

	// 管理员日志
	function add_admin($msg){

		return $this->ci->log_model->add_admin($msg);
	}

	// 管理员操作水卡日志
	function add_admin_card($wl, $msg){

		return $this->ci->log_model->add_admin_card($wl, $msg);
	}

}
