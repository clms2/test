<?php 
class Customer_Service extends Common_Service{

	public function __construct(){
		parent::__construct();
		$this->ci->load->model('admin/Customer_model', 'customer');
	}

	/**
	 * 获取所有经销商对应关系列表
	 * @return array array(jxs_id=>array(title=>title,child=>array(jxs_id => array(title=>title),..)))
	 */
	function get_all_customer_map(){

		return $this->ci->customer->get_all_customer_map();
	}

	function get_jxs_by_id($id, $field = 'shuidj'){

		return $this->ci->customer->get_jxs_by_id($id, $field);
	}

}
