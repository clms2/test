<?php 
require_once APPPATH.'services/AdminUser_Service.php';
class Login_Service extends AdminUser_Service{

	public function __construct(){
		parent::__construct();
	}

	public function check_login($uname = '', $pwd = ''){
		if(empty($uname)) $uname = $this->input->post('uname');
		if(empty($pwd)) $pwd = $this->input->post('pwd');

		$ret = array('code' => 1);
		if(empty($uname) || empty($pwd)){
			$ret['code'] = -1;
			$ret['msg']  = '用户名或密码不能为空';
			return $ret;
		}

		$user = $this->get_user_by_name($uname, 'user_name,user_id,password,ec_salt,action_list,jxs_id,last_login,last_ip,status');
		if(empty($user)){
			$ret['code'] = -1;
			$ret['msg']  = '请输入正确的用户名或密码';
			return $ret;
		}

		if($user['status'] != '1'){
			$ret['code'] = -3;
			$ret['msg']  = '该账号已禁用，请联系管理员处理';
			return $ret;
		}

		if($this->get_encrypted_pwd($pwd, $user['ec_salt']) !== $user['password']){
			$ret['code'] = -1;
			$ret['msg']  = '请输入正确的用户名或密码';
			return $ret;
		}
		$ret['user'] = $user;
		
		return $ret;
	}

}
